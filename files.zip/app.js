/* ═══════════════════════════════════════════════════════════
   Cumart CRM – Application Script
   Version 1.9.0 (Einsätze / Phase 3c)
   ═══════════════════════════════════════════════════════════ */

'use strict';

// ── KONFIGURATION ────────────────────────────────────────────
const SUPABASE_URL        = 'https://loohjeiysjxzbmfwkyvv.supabase.co';
const SUPABASE_ANON_KEY   = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxvb2hqZWl5c2p4emJtZndreXZ2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY0MjUwNzUsImV4cCI6MjA5MjAwMTA3NX0.L75kTzqx4hJY7buBFv9iMZ-mrQ3vdNqB-G50MPpRbNw';
const FUNCTIONS_URL       = SUPABASE_URL + '/functions/v1';

const { createClient } = supabase;
const db = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// SVG-Copy-Icon als String-Konstante
const COPY_ICON_SVG = `
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"
       stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
  </svg>`;

// ── APP STATE ────────────────────────────────────────────────
let currentUser        = null;
let currentProfile     = null;
let allRoles           = [];
let editingUserId      = null;
let editingServiceId   = null;
let editingLookupId    = null;
let editingCompanyId   = null;
let editingContactId   = null;
let editingAppointmentId = null;
let inPasswordRecovery = false;

let currentCompanyDetailId = null;
let currentProjectDetailId = null;
let currentContactDetailId = null;
let contactModalPrefillCompanyId = null;
let appointmentModalPrefillCompanyId = null;
let appointmentModalPrefillProjectId = null;
let appointmentModalPrefillContactId = null;
let projectModalPrefillCompanyId = null;
let projectModalPrefillHauptkontaktId = null;
let deploymentModalPrefillCompanyId = null;
let deploymentModalPrefillProjectId = null;
let editingProjectId = null;
let editingDeploymentId = null;

let companiesCache   = [];
let contactsCache    = [];
let appointmentsCache = [];
let projectsCache    = [];
let deploymentsCache = [];
let terminTypenCache = [];
let projektStatusCache = [];
let einsatzStatusCache = [];
let servicesCache    = [];
let userProfilesCache = [];

// Map: companyId → contacts[] (für synchronen Copy-Zugriff)
let companyContactsMap = {};

// Selected Techniker IDs im Einsatz-Modal (temporär)
let selectedTechnikerIds = new Set();

// Map: companyId → { next: {datum, titel, id} | null, last: {datum, titel, id} | null }
let companyAppointmentMap = {};

// Pending filter für Termine, kommt aus URL-Hash-Parametern
let pendingAppointmentsFilter = null;

// Auto-Fill-Tracking für Ort-Feld
let lastAutoFilledOrt = '';

// ── HILFSFUNKTIONEN ──────────────────────────────────────────
function ini(name) {
  return (name || '?').split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
}

function statusLabel(s) { return { eingeladen: 'Eingeladen', aktiv: 'Aktiv', inaktiv: 'Inaktiv' }[s] || 'Unbekannt'; }
function statusBg(s) { return { eingeladen: '#fffbeb', aktiv: '#f0fdf4', inaktiv: '#fef2f2' }[s] || '#f3f4f6'; }
function statusColor(s) { return { eingeladen: '#d97706', aktiv: '#16a34a', inaktiv: '#dc2626' }[s] || '#6b7280'; }

function isAdmin() { return currentProfile?.roles?.name === 'Admin'; }

function formatPreis(value) {
  if (value === null || value === undefined || value === '') return '—';
  const num = Number(value);
  if (Number.isNaN(num)) return '—';
  return num.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' €';
}

function esc(s) {
  return (s ?? '').toString()
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ═══════════════════════════════════════════════════════════
//  INPUT-SANITIZER (Tipp-Zeit-Validierung)
// ═══════════════════════════════════════════════════════════

/** Erlaubt nur telefon-taugliche Zeichen: Ziffern, +, -, (, ), /, ., Leerzeichen */
function sanitizePhoneInput(el) {
  const before = el.value;
  const after  = before.replace(/[^\d+\-()\/. ]/g, '');
  if (before !== after) {
    const pos = el.selectionStart - (before.length - after.length);
    el.value = after;
    try { el.setSelectionRange(pos, pos); } catch {}
  }
}

/** Erlaubt nur Ziffern (z.B. PLZ) */
function sanitizeNumericInput(el, maxLen = null) {
  const before = el.value;
  let after = before.replace(/\D/g, '');
  if (maxLen) after = after.slice(0, maxLen);
  if (before !== after) {
    const pos = el.selectionStart - (before.length - after.length);
    el.value = after;
    try { el.setSelectionRange(pos, pos); } catch {}
  }
}

/** Trimmt und kleinbuchstabiert E-Mail sanft (keine Auto-Lowercasing beim Tippen, nur on blur) */
function sanitizeEmailOnBlur(el) {
  el.value = el.value.trim();
}

function showToast(msg, isError = false) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show' + (isError ? ' error' : '');
  setTimeout(() => t.className = 'toast', 3000);
}

async function copyToClipboard(text, toastMsg = 'In Zwischenablage kopiert.') {
  // Diese Version wird für Kontext ohne User-Gesture-Druck verwendet (z.B. Credentials-Modal)
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      showToast(toastMsg);
      return true;
    }
    return copyTextSync(text, toastMsg);
  } catch (e) {
    // Fallback auf synchrone Variante
    return copyTextSync(text, toastMsg);
  }
}

/**
 * Synchron kopieren - iOS-kompatibel, funktioniert nur wenn direkt
 * aus einem User-Click-Event aufgerufen (kein async/await davor!).
 */
function copyTextSync(text, toastMsg = 'In Zwischenablage kopiert.') {
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.top = '0';
    ta.style.left = '0';
    ta.style.width = '1px';
    ta.style.height = '1px';
    ta.style.opacity = '0';
    ta.style.fontSize = '16px'; // verhindert iOS-Zoom
    document.body.appendChild(ta);

    // iOS-Trick: Range + Selection für contenteditable workaround
    ta.contentEditable = 'true';
    ta.readOnly = false;
    const range = document.createRange();
    range.selectNodeContents(ta);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    ta.setSelectionRange(0, 999999);
    ta.focus();
    ta.select();

    const ok = document.execCommand('copy');
    document.body.removeChild(ta);

    if (!ok) throw new Error('Kopierbefehl fehlgeschlagen');
    showToast(toastMsg);
    return true;
  } catch (e) {
    showToast('Kopieren nicht möglich.', true);
    return false;
  }
}

function formatCompanyBlock(company, contacts = []) {
  const lines = [];
  if (company.name) lines.push(company.name);
  if (company.strasse) lines.push(company.strasse);
  const ort = [company.plz, company.stadt].filter(Boolean).join(' ').trim();
  if (ort) lines.push(ort);

  const kontaktNamen = (contacts || [])
    .map(k => [k.vorname, k.nachname].filter(Boolean).join(' ').trim())
    .filter(Boolean);
  if (kontaktNamen.length > 0) {
    lines.push('');
    lines.push(...kontaktNamen);
  }
  return lines.join('\n');
}

function formatContactBlock(contact) {
  const lines = [];
  const fullName = [contact.vorname, contact.nachname].filter(Boolean).join(' ').trim();
  if (fullName) lines.push(fullName);
  if (contact.email) lines.push(contact.email);
  if (contact.telefon) lines.push(contact.telefon);
  const company = contact.company;
  if (company) {
    if (company.name) lines.push(company.name);
    if (company.strasse) lines.push(company.strasse);
    const ort = [company.plz, company.stadt].filter(Boolean).join(' ').trim();
    if (ort) lines.push(ort);
  }
  return lines.join('\n');
}

/**
 * SYNCHRON - darf keine async-Calls vor dem Copy haben (iOS-Bedingung).
 * Greift auf Caches zu: companiesCache, companyContactsMap.
 */
function copyCompanyById(companyId) {
  const company = companiesCache.find(c => c.id === companyId);
  if (!company) {
    showToast('Firma noch nicht geladen. Bitte kurz warten und erneut versuchen.', true);
    return;
  }
  const contacts = companyContactsMap[companyId] || [];
  const text = formatCompanyBlock(company, contacts);
  copyTextSync(text, 'Firmendaten kopiert.');
}

/**
 * SYNCHRON - sucht Kontakt in contactsCache oder companyContactsMap.
 */
function copyContactById(contactId) {
  let contact = null;

  // Erst contactsCache (hat meist .company dabei)
  if (contactsCache.length > 0) {
    contact = contactsCache.find(c => c.id === contactId);
  }

  // Sonst aus companyContactsMap zusammenbauen
  if (!contact) {
    for (const [cid, list] of Object.entries(companyContactsMap)) {
      const hit = list.find(c => c.id === contactId);
      if (hit) {
        const company = companiesCache.find(c => c.id === cid);
        contact = { ...hit, company };
        break;
      }
    }
  }

  if (!contact) {
    showToast('Kontakt noch nicht geladen. Bitte kurz warten und erneut versuchen.', true);
    return;
  }
  const text = formatContactBlock(contact);
  copyTextSync(text, 'Kontakt kopiert.');
}

// ═══════════════════════════════════════════════════════════
//  DATUM/ZEIT-HILFSFUNKTIONEN
// ═══════════════════════════════════════════════════════════

function parseLocalDate(isoDateStr) {
  const [y, m, d] = isoDateStr.split('-').map(Number);
  return new Date(y, m - 1, d);
}

function toISODate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function formatDateDE(isoDateStr) {
  if (!isoDateStr) return '—';
  try {
    const d = parseLocalDate(isoDateStr);
    const wd = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d.getDay()];
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    return `${wd}, ${day}.${month}.${year}`;
  } catch {
    return isoDateStr;
  }
}

/** Kompaktere Version für Firmen-Liste: "Di 21.04.26" */
function formatDateCompact(isoDateStr) {
  if (!isoDateStr) return '—';
  try {
    const d = parseLocalDate(isoDateStr);
    const wd = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'][d.getDay()];
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = String(d.getFullYear()).slice(2);
    return `${wd} ${day}.${month}.${year}`;
  } catch {
    return isoDateStr;
  }
}

function formatTime(timeStr) {
  if (!timeStr) return '';
  return timeStr.substring(0, 5);
}

function appointmentStatusBg(s)    { return s === 'geplant' ? '#eff6ff' : '#f0fdf4'; }
function appointmentStatusColor(s) { return s === 'geplant' ? '#1d4ed8' : '#16a34a'; }
function appointmentStatusLabel(s) { return s === 'geplant' ? 'Geplant' : 'Durchgeführt'; }

function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item:not(.nav-item-group)').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + name)?.classList.add('active');

  const navBtn = document.getElementById('nav-' + name);
  if (navBtn) navBtn.classList.add('active');

  setMobileNav(name);

  if (name === 'users') loadUsers();
  if (name === 'services') loadServices();
  if (name === 'lookups') loadLookupsPage();
  if (name === 'companies') loadCompanies();
  if (name === 'contacts') loadContacts();
  if (name === 'appointments') loadAppointments();
  if (name === 'projects') loadProjects();
  if (name === 'deployments') loadDeployments();
}

function setMobileNav(pageName) {
  document.querySelectorAll('.mobile-nav-item').forEach(el => el.classList.remove('active'));

  if (pageName === 'companies' || pageName === 'company-detail') {
    document.getElementById('m-nav-companies')?.classList.add('active');
  } else if (pageName === 'appointments') {
    document.getElementById('m-nav-appointments')?.classList.add('active');
  } else if (pageName === 'deployments') {
    document.getElementById('m-nav-deployments')?.classList.add('active');
  } else {
    // contacts, contact-detail, projects, project-detail, users, services, lookups → Mehr-Tab
    document.getElementById('m-nav-more')?.classList.add('active');
  }
}

function toggleSettings() {
  document.getElementById('nav-settings-group').classList.toggle('open');
}

function openMoreMenu()  { document.getElementById('more-overlay').classList.add('open'); }
function closeMoreMenu(event) {
  if (event && event.target !== event.currentTarget) return;
  document.getElementById('more-overlay').classList.remove('open');
}

// ═══════════════════════════════════════════════════════════
//  HASH-ROUTER
// ═══════════════════════════════════════════════════════════

function navigateTo(page, param) {
  let hash;
  if (page === 'firma' && param) {
    hash = `#/firma/${param}`;
  } else if (page === 'projekt' && param) {
    hash = `#/projekt/${param}`;
  } else if (page === 'kontakt' && param) {
    hash = `#/kontakt/${param}`;
  } else if (page === 'appointments' && param && typeof param === 'object' && param.firma) {
    hash = `#/termine?firma=${param.firma}`;
  } else if (page === 'appointments' && param && typeof param === 'object' && param.projekt) {
    hash = `#/termine?projekt=${param.projekt}`;
  } else if (page === 'companies') {
    hash = '#/firmen';
  } else if (page === 'contacts') {
    hash = '#/kontakte';
  } else if (page === 'appointments') {
    hash = '#/termine';
  } else if (page === 'projects') {
    hash = '#/projekte';
  } else if (page === 'deployments') {
    hash = '#/einsaetze';
  } else if (page === 'users') {
    hash = '#/benutzer';
  } else if (page === 'services') {
    hash = '#/leistungen';
  } else if (page === 'lookups') {
    hash = '#/stammdaten';
  } else {
    hash = '#/firmen';
  }
  window.location.hash = hash;
}

function parseHashQuery(hashPart) {
  const idx = hashPart.indexOf('?');
  if (idx < 0) return { path: hashPart, params: {} };
  const path = hashPart.substring(0, idx);
  const query = hashPart.substring(idx + 1);
  const params = {};
  query.split('&').forEach(pair => {
    if (!pair) return;
    const [k, v] = pair.split('=');
    params[decodeURIComponent(k)] = decodeURIComponent(v || '');
  });
  return { path, params };
}

function handleHashChange() {
  if (document.getElementById('app').style.display === 'none') return;
  if (inPasswordRecovery) return;

  const hash = window.location.hash || '';

  if (hash.startsWith('#/firma/')) {
    const id = hash.slice('#/firma/'.length);
    if (id) { loadCompanyDetail(id); return; }
  }

  if (hash.startsWith('#/projekt/')) {
    const id = hash.slice('#/projekt/'.length);
    if (id) { loadProjectDetail(id); return; }
  }

  if (hash.startsWith('#/kontakt/')) {
    const id = hash.slice('#/kontakt/'.length);
    if (id) { loadContactDetail(id); return; }
  }

  if (hash.startsWith('#/termine')) {
    const { params } = parseHashQuery(hash);
    if (params.firma)   pendingAppointmentsFilter = { firma: params.firma };
    if (params.projekt) pendingAppointmentsFilter = { projekt: params.projekt };
    showPage('appointments');
    return;
  }

  if (hash === '#/firmen' || hash === '' || hash === '#') { showPage('companies'); return; }
  if (hash === '#/kontakte')   { showPage('contacts'); return; }
  if (hash === '#/projekte')   { showPage('projects'); return; }
  if (hash === '#/einsaetze')  { showPage('deployments'); return; }
  if (hash === '#/benutzer')   { showPage('users'); return; }
  if (hash === '#/leistungen') { showPage('services'); return; }
  if (hash === '#/stammdaten') { showPage('lookups'); return; }

  showPage('companies');
}

// ── SCREEN-WECHSEL ───────────────────────────────────────────
function hideAllScreens() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('reset-screen').style.display = 'none';
  document.getElementById('recovery-screen').style.display = 'none';
  document.getElementById('mustchange-screen').style.display = 'none';
  document.getElementById('app').style.display = 'none';
}

function showLoginScreen()    { hideAllScreens(); document.getElementById('auth-screen').style.display = 'flex'; }
function showResetScreen()    { hideAllScreens(); document.getElementById('reset-screen').style.display = 'flex'; }
function showRecoveryScreen() { hideAllScreens(); document.getElementById('recovery-screen').style.display = 'flex'; setTimeout(() => document.getElementById('recovery-1').focus(), 100); }
function showMustChangeScreen() { hideAllScreens(); document.getElementById('mustchange-screen').style.display = 'flex'; setTimeout(() => document.getElementById('mustchange-1').focus(), 100); }
function showApp()            { hideAllScreens(); document.getElementById('app').style.display = 'flex'; }

// ── AUTH INIT ────────────────────────────────────────────────
async function initAuth() {
  const hash = window.location.hash;

  if (hash.includes('type=recovery') || hash.includes('type=invite')) {
    inPasswordRecovery = true;
    showRecoveryScreen();
    db.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_OUT') { inPasswordRecovery = false; showLoginScreen(); }
    });
    return;
  }

  try {
    const { data: { session } } = await db.auth.getSession();
    if (session) await onLogin(session.user);
    else showLoginScreen();
  } catch (e) { showLoginScreen(); }

  db.auth.onAuthStateChange(async (event, session) => {
    if (inPasswordRecovery) return;
    if (event === 'SIGNED_OUT') {
      currentUser = null;
      currentProfile = null;
      showLoginScreen();
    }
    if (event === 'SIGNED_IN' && session && !currentUser) {
      await onLogin(session.user);
    }
  });

  window.addEventListener('hashchange', handleHashChange);
}

// ── LOGIN-FLOW ───────────────────────────────────────────────
async function onLogin(user) {
  currentUser = user;

  const { data: profile, error: profileError } = await db
    .from('user_profiles')
    .select('*, roles(id, name, rechte)')
    .eq('id', user.id).single();

  if (profileError || !profile) {
    await db.auth.signOut();
    currentUser = null;
    showLoginScreen();
    showToast('Benutzerprofil nicht gefunden. Bitte wende dich an einen Administrator.', true);
    return;
  }

  if (profile.status === 'inaktiv') {
    await db.auth.signOut();
    currentUser = null;
    showLoginScreen();
    showToast('Dein Konto ist deaktiviert. Bitte wende dich an einen Administrator.', true);
    return;
  }

  currentProfile = profile;

  if (profile.muss_passwort_aendern === true) {
    showMustChangeScreen();
    return;
  }

  renderSidebar();
  renderMobileHeaderUser();
  applyAdminOnlyUI();
  showApp();

  if (isAdmin()) {
    document.getElementById('nav-settings-group').classList.add('open');
  }

  await loadRoles();

  if (window.location.hash && window.location.hash !== '#') {
    handleHashChange();
  } else {
    navigateTo('companies');
  }
}

function applyAdminOnlyUI() {
  const admin = isAdmin();
  document.querySelectorAll('[data-admin-only="true"]').forEach(el => {
    el.style.display = admin ? '' : 'none';
  });
  document.getElementById('btn-new-user').style.display = admin ? 'inline-block' : 'none';
  document.getElementById('btn-new-service').style.display = admin ? 'inline-block' : 'none';
}

function renderSidebar() {
  const bar = document.getElementById('sidebar-user');
  bar.innerHTML = `
    <div class="sidebar-user-avatar">${esc(ini(currentProfile?.name || currentUser.email))}</div>
    <div class="sidebar-user-info">
      <div class="sidebar-user-name">${esc(currentProfile?.name || currentUser.email)}</div>
      <div class="sidebar-user-role">${esc(currentProfile?.roles?.name || '—')}</div>
    </div>`;
}

function renderMobileHeaderUser() {
  const el = document.getElementById('mobile-header-user');
  if (!el) return;
  el.innerHTML = `
    <span class="mobile-header-user-name">${esc(currentProfile?.name || currentUser.email)}</span>
    <div class="sidebar-user-avatar" style="width:30px;height:30px">${esc(ini(currentProfile?.name || currentUser.email))}</div>
  `;
}

async function doLogin() {
  const email    = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const errEl    = document.getElementById('auth-error');
  const btn      = document.getElementById('auth-btn');

  errEl.classList.remove('show');
  if (!email || !password) {
    errEl.textContent = 'Bitte E-Mail und Passwort eingeben.';
    errEl.classList.add('show');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Anmelden ...';

  try {
    const { data, error } = await db.auth.signInWithPassword({ email, password });
    if (error) throw new Error(
      error.message === 'Invalid login credentials' ? 'E-Mail oder Passwort falsch.' : error.message
    );
    await onLogin(data.user);
  } catch (e) {
    errEl.textContent = e.message;
    errEl.classList.add('show');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Anmelden';
  }
}

async function doLogout(skipConfirm = false) {
  if (!skipConfirm && !confirm('Wirklich abmelden?')) return;
  document.getElementById('more-overlay')?.classList.remove('open');
  await db.auth.signOut();
  currentUser = null;
  currentProfile = null;
  inPasswordRecovery = false;
  window.location.hash = '';
  showLoginScreen();
}

async function doReset() {
  const email = document.getElementById('reset-email').value.trim();
  const errEl = document.getElementById('reset-error');
  const btn   = document.getElementById('reset-btn');
  const sucEl = document.getElementById('reset-success');

  errEl.classList.remove('show');
  sucEl.style.display = 'none';
  if (!email) { errEl.textContent = 'Bitte E-Mail eingeben.'; errEl.classList.add('show'); return; }

  btn.disabled = true;
  btn.textContent = 'Wird gesendet ...';

  const { error } = await db.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });

  btn.disabled = false;
  btn.textContent = 'Link senden';

  if (error) { errEl.textContent = error.message; errEl.classList.add('show'); }
  else { sucEl.style.display = 'block'; }
}

async function doMustChangePassword() {
  const pw1 = document.getElementById('mustchange-1').value;
  const pw2 = document.getElementById('mustchange-2').value;
  const errEl = document.getElementById('mustchange-error');
  const btn = document.getElementById('mustchange-btn');

  errEl.classList.remove('show');

  if (pw1.length < 6) { errEl.textContent = 'Passwort muss mindestens 6 Zeichen haben.'; errEl.classList.add('show'); return; }
  if (pw1 !== pw2) { errEl.textContent = 'Passwörter stimmen nicht überein.'; errEl.classList.add('show'); return; }

  btn.disabled = true;
  btn.textContent = 'Wird gespeichert ...';

  try {
    const { error: pwError } = await db.auth.updateUser({ password: pw1 });
    if (pwError) throw new Error(pwError.message);

    const { error: flagError } = await db
      .from('user_profiles').update({ muss_passwort_aendern: false })
      .eq('id', currentUser.id);
    if (flagError) throw new Error(flagError.message);

    const { data: profile, error: profileError } = await db
      .from('user_profiles').select('*, roles(id, name, rechte)')
      .eq('id', currentUser.id).single();
    if (profileError || !profile) throw new Error('Profil konnte nicht geladen werden.');

    currentProfile = profile;
    renderSidebar();
    renderMobileHeaderUser();
    applyAdminOnlyUI();
    showApp();

    if (isAdmin()) document.getElementById('nav-settings-group').classList.add('open');
    await loadRoles();
    navigateTo('companies');

    showToast('Passwort erfolgreich geändert.');
  } catch (e) {
    errEl.textContent = e.message;
    errEl.classList.add('show');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Passwort speichern';
  }
}

async function doRecoveryPassword() {
  const pw1 = document.getElementById('recovery-1').value;
  const pw2 = document.getElementById('recovery-2').value;
  const errEl = document.getElementById('recovery-error');
  const btn = document.getElementById('recovery-btn');

  errEl.classList.remove('show');

  if (pw1.length < 6) { errEl.textContent = 'Passwort muss mindestens 6 Zeichen haben.'; errEl.classList.add('show'); return; }
  if (pw1 !== pw2) { errEl.textContent = 'Passwörter stimmen nicht überein.'; errEl.classList.add('show'); return; }

  btn.disabled = true;
  btn.textContent = 'Wird gespeichert ...';

  try {
    const { error } = await db.auth.updateUser({ password: pw1 });
    if (error) throw new Error(error.message);

    window.history.replaceState(null, '', window.location.pathname);
    inPasswordRecovery = false;

    const { data: { session } } = await db.auth.getSession();
    if (!session) { showToast('Passwort gesetzt. Bitte neu anmelden.'); showLoginScreen(); return; }

    await onLogin(session.user);
    showToast('Passwort erfolgreich geändert.');
  } catch (e) {
    errEl.textContent = e.message;
    errEl.classList.add('show');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Passwort speichern & einloggen';
  }
}

// ═══════════════════════════════════════════════════════════
//  BENUTZER-VERWALTUNG
// ═══════════════════════════════════════════════════════════

async function loadRoles() {
  const { data, error } = await db.from('roles').select('*').eq('ist_aktiv', true).order('name');
  if (error) { showToast('Fehler beim Laden der Rollen: ' + error.message, true); return; }
  allRoles = data || [];
}

async function loadUsers() {
  const tbody = document.getElementById('users-table-body');
  tbody.innerHTML = '<tr><td colspan="5"><div class="empty">Lade ...</div></td></tr>';

  const { data: users, error } = await db.from('user_profiles').select('*, roles(name)').order('name');

  if (error) {
    tbody.innerHTML = `<tr><td colspan="5"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    return;
  }
  if (!users || users.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5"><div class="empty">Noch keine Benutzer.</div></td></tr>';
    return;
  }

  const canAdminister = isAdmin();

  tbody.innerHTML = users.map(u => {
    const isMe = u.id === currentUser?.id;
    const roleColor = u.roles?.name === 'Admin' ? '#1d4ed8' : '#374151';
    const roleBg    = u.roles?.name === 'Admin' ? '#eff6ff' : '#f3f4f6';

    let actions = '';
    if (canAdminister) {
      actions += `<button class="btn btn-sm" onclick="openUserModal('edit', '${u.id}')">Bearbeiten</button>`;
      if (!isMe) {
        actions += `<button class="btn btn-sm" onclick="resetUserPassword('${u.id}', '${esc(u.name || '')}')">Passwort zurücksetzen</button>`;
      }
    }

    const nameHtml = canAdminister
      ? `<div class="cell-link" onclick="openUserModal('edit', '${esc(u.id)}')">${esc(u.name)}</div>`
      : `<div style="font-weight:500">${esc(u.name)}</div>`;

    return `
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div class="avatar">${esc(ini(u.name))}</div>
            <div>
              ${nameHtml}
              ${isMe ? '<div style="font-size:11px;color:var(--muted)">Das bist du</div>' : ''}
            </div>
          </div>
        </td>
        <td style="color:var(--muted)">${esc(u.email)}</td>
        <td><span class="badge" style="background:${roleBg};color:${roleColor}">${esc(u.roles?.name || '—')}</span></td>
        <td><span class="badge" style="background:${statusBg(u.status)};color:${statusColor(u.status)}">${esc(statusLabel(u.status))}</span></td>
        <td class="col-action" style="text-align:right"><div class="btn-row" style="justify-content:flex-end">${actions}</div></td>
      </tr>`;
  }).join('');
}

async function openUserModal(mode, userId = null) {
  if (!isAdmin()) { showToast('Du hast keine Berechtigung für diese Aktion.', true); return; }
  editingUserId = userId;

  const roleSelect = document.getElementById('u-role');
  roleSelect.innerHTML = allRoles.map(r => `<option value="${esc(r.id)}">${esc(r.name)}</option>`).join('');
  roleSelect.disabled = false;

  document.getElementById('u-name').value = '';
  document.getElementById('u-email').value = '';
  document.getElementById('u-password').value = '';

  if (mode === 'new') {
    document.getElementById('modal-user-title').textContent = 'Neuer Benutzer';
    document.getElementById('u-password-hint').textContent = '(leer = automatisch generieren)';
    document.getElementById('u-password').placeholder = 'Leer lassen für automatisches Passwort';
    document.getElementById('u-save-btn').textContent = 'Anlegen';
    document.getElementById('u-delete-btn').style.display = 'none';
    document.getElementById('u-email').disabled = false;
    document.getElementById('u-password-group').style.display = '';
  } else {
    const isEditingSelf = userId === currentUser?.id;
    document.getElementById('modal-user-title').textContent = isEditingSelf ? 'Mein Profil' : 'Benutzer bearbeiten';
    document.getElementById('u-password-hint').textContent = '(leer = unverändert)';
    document.getElementById('u-password').placeholder = 'Leer lassen für unverändertes Passwort';
    document.getElementById('u-save-btn').textContent = 'Speichern';
    document.getElementById('u-delete-btn').style.display = isEditingSelf ? 'none' : 'block';
    document.getElementById('u-email').disabled = true;
    roleSelect.disabled = isEditingSelf;
    document.getElementById('u-password-group').style.display = '';

    const { data, error } = await db.from('user_profiles').select('*, roles(id, name)').eq('id', userId).single();
    if (error || !data) { showToast('Benutzer konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingUserId = null; return; }
    document.getElementById('u-name').value = data.name || '';
    document.getElementById('u-email').value = data.email || '';
    if (data.role_id) roleSelect.value = data.role_id;
  }

  document.getElementById('modal-user').classList.add('open');
  setTimeout(() => document.getElementById('u-name').focus(), 100);
}

function closeUserModal() { document.getElementById('modal-user').classList.remove('open'); editingUserId = null; }

async function saveUser() {
  const name     = document.getElementById('u-name').value.trim();
  const email    = document.getElementById('u-email').value.trim();
  const role_id  = document.getElementById('u-role').value;
  const password = document.getElementById('u-password').value;
  const btn      = document.getElementById('u-save-btn');

  if (!name) { showToast('Bitte Name eingeben.', true); return; }
  if (!editingUserId && !email) { showToast('Bitte E-Mail eingeben.', true); return; }
  if (!role_id) { showToast('Bitte Rolle auswählen.', true); return; }
  if (password && password.length < 6) { showToast('Passwort muss mind. 6 Zeichen haben.', true); return; }

  btn.disabled = true;
  btn.textContent = editingUserId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const { data: { session } } = await db.auth.getSession();
    if (!session?.access_token) throw new Error('Nicht eingeloggt.');

    const body = editingUserId
      ? { action: 'update', user_id: editingUserId, name, role_id, password: password || undefined }
      : { action: 'invite', email, name, role_id, password: password || undefined };

    const resp = await fetch(`${FUNCTIONS_URL}/manage-users`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + session.access_token, 'apikey': SUPABASE_ANON_KEY },
      body: JSON.stringify(body)
    });
    const result = await resp.json();
    if (!resp.ok) throw new Error(result.error || 'Unbekannter Fehler');

    closeUserModal();
    if (editingUserId) {
      showToast('Benutzer aktualisiert.');
    } else {
      showCredentials({ title: 'Zugangsdaten für ' + name, email: result.email, password: result.password });
    }
    await loadUsers();
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingUserId ? 'Speichern' : 'Anlegen';
  }
}

async function deleteUser() {
  if (!editingUserId) return;
  if (editingUserId === currentUser?.id) { showToast('Du kannst dich nicht selbst löschen.', true); return; }
  if (!confirm('Benutzer wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.')) return;

  const btn = document.getElementById('u-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const { data: { session } } = await db.auth.getSession();
    if (!session?.access_token) throw new Error('Nicht eingeloggt.');

    const resp = await fetch(`${FUNCTIONS_URL}/manage-users`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + session.access_token, 'apikey': SUPABASE_ANON_KEY },
      body: JSON.stringify({ action: 'delete', user_id: editingUserId })
    });
    const result = await resp.json();
    if (!resp.ok) throw new Error(result.error || 'Unbekannter Fehler');

    closeUserModal();
    showToast('Benutzer gelöscht.');
    await loadUsers();
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

async function resetUserPassword(userId, userName) {
  if (!isAdmin()) { showToast('Du hast keine Berechtigung für diese Aktion.', true); return; }
  if (!confirm(`Für "${userName}" ein neues Passwort generieren?\n\nDas alte Passwort wird sofort ungültig. Der Benutzer muss sich beim nächsten Login ein eigenes Passwort setzen.`)) return;

  try {
    const { data: { session } } = await db.auth.getSession();
    if (!session?.access_token) throw new Error('Nicht eingeloggt.');

    const resp = await fetch(`${FUNCTIONS_URL}/manage-users`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + session.access_token, 'apikey': SUPABASE_ANON_KEY },
      body: JSON.stringify({ action: 'reset_password', user_id: userId })
    });
    const result = await resp.json();
    if (!resp.ok) throw new Error(result.error || 'Unbekannter Fehler');

    showCredentials({ title: 'Neues Passwort für ' + userName, email: result.email, password: result.password });
    await loadUsers();
  } catch (e) {
    showToast(e.message, true);
  }
}

function showCredentials({ title, email, password }) {
  document.getElementById('modal-credentials-title').textContent = title;
  document.getElementById('cred-email').textContent = email;
  document.getElementById('cred-password').textContent = password;
  document.getElementById('modal-credentials').classList.add('open');
}

function closeCredentialsModal() {
  document.getElementById('modal-credentials').classList.remove('open');
  document.getElementById('cred-email').textContent = '';
  document.getElementById('cred-password').textContent = '';
}

async function copyCredential(elementId) {
  await copyToClipboard(document.getElementById(elementId).textContent);
}

async function copyBothCredentials() {
  const email = document.getElementById('cred-email').textContent;
  const password = document.getElementById('cred-password').textContent;
  await copyToClipboard(`E-Mail: ${email}\nPasswort: ${password}`, 'Zugangsdaten in Zwischenablage kopiert.');
}

// ═══════════════════════════════════════════════════════════
//  LEISTUNGEN (SERVICES)
// ═══════════════════════════════════════════════════════════

async function loadLeistungsKategorien() {
  const { data, error } = await db.from('lookup_values')
    .select('id, wert, farbe').eq('kategorie', 'leistungs_kategorie').eq('ist_aktiv', true).order('reihenfolge');
  if (error) { showToast('Fehler beim Laden der Kategorien: ' + error.message, true); return []; }
  return data || [];
}

async function loadServices() {
  const tbody = document.getElementById('services-table-body');
  tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Lade ...</div></td></tr>';

  const { data, error } = await db.from('services')
    .select('*, kategorie:lookup_values!services_kategorie_id_fkey(id, wert, farbe)').order('name');

  if (error) { tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`; return; }
  if (!data || data.length === 0) {
    const hint = isAdmin() ? 'Noch keine Leistungen angelegt. Klicke oben auf „+ Neue Leistung".' : 'Noch keine Leistungen verfügbar.';
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">${hint}</div></td></tr>`;
    return;
  }

  const canEdit = isAdmin();

  tbody.innerHTML = data.map(s => {
    const katFarbe = s.kategorie?.farbe || '#6b7280';
    const katWert  = s.kategorie?.wert || '—';
    const aktivBg  = s.ist_aktiv ? '#f0fdf4' : '#f3f4f6';
    const aktivCol = s.ist_aktiv ? '#16a34a' : '#6b7280';
    const aktivTxt = s.ist_aktiv ? 'Aktiv' : 'Archiviert';
    const editBtn = canEdit ? `<button class="btn btn-sm" onclick="openServiceModal('edit', '${s.id}')">Bearbeiten</button>` : '';

    const nameHtml = canEdit
      ? `<div class="cell-link" onclick="openServiceModal('edit', '${esc(s.id)}')">${esc(s.name)}</div>`
      : `<div style="font-weight:500">${esc(s.name)}</div>`;

    return `
      <tr>
        <td>
          ${nameHtml}
          ${s.beschreibung ? `<div style="font-size:11px;color:var(--muted);margin-top:2px">${esc(s.beschreibung)}</div>` : ''}
        </td>
        <td><span class="badge" style="background:${esc(katFarbe)}22;color:${esc(katFarbe)}">${esc(katWert)}</span></td>
        <td style="color:var(--muted)">${esc(s.einheit || '—')}</td>
        <td>${esc(formatPreis(s.standardpreis))}</td>
        <td><span class="badge" style="background:${aktivBg};color:${aktivCol}">${aktivTxt}</span></td>
        <td class="col-action" style="text-align:right">${editBtn}</td>
      </tr>`;
  }).join('');
}

async function openServiceModal(mode, serviceId = null) {
  if (!isAdmin()) { showToast('Du hast keine Berechtigung für diese Aktion.', true); return; }
  editingServiceId = serviceId;

  const kategorien = await loadLeistungsKategorien();
  const kategorieSelect = document.getElementById('s-kategorie');
  if (kategorien.length === 0) {
    kategorieSelect.innerHTML = '<option value="">Keine Kategorien – bitte erst unter „Stammdaten" anlegen</option>';
  } else {
    kategorieSelect.innerHTML = kategorien.map(k => `<option value="${esc(k.id)}">${esc(k.wert)}</option>`).join('');
  }

  document.getElementById('s-name').value = '';
  document.getElementById('s-beschreibung').value = '';
  document.getElementById('s-einheit').value = 'Tag';
  document.getElementById('s-preis').value = '';
  document.getElementById('s-aktiv').value = 'true';

  if (mode === 'new') {
    document.getElementById('modal-service-title').textContent = 'Neue Leistung';
    document.getElementById('s-save-btn').textContent = 'Anlegen';
    document.getElementById('s-delete-btn').style.display = 'none';
  } else {
    document.getElementById('modal-service-title').textContent = 'Leistung bearbeiten';
    document.getElementById('s-save-btn').textContent = 'Speichern';
    document.getElementById('s-delete-btn').style.display = 'block';

    const { data, error } = await db.from('services').select('*').eq('id', serviceId).single();
    if (error || !data) { showToast('Leistung konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingServiceId = null; return; }
    document.getElementById('s-name').value = data.name || '';
    document.getElementById('s-beschreibung').value = data.beschreibung || '';
    document.getElementById('s-einheit').value = data.einheit || 'Tag';
    document.getElementById('s-preis').value = data.standardpreis ?? '';
    document.getElementById('s-aktiv').value = data.ist_aktiv ? 'true' : 'false';
    if (data.kategorie_id) kategorieSelect.value = data.kategorie_id;
  }

  document.getElementById('modal-service').classList.add('open');
  setTimeout(() => document.getElementById('s-name').focus(), 100);
}

function closeServiceModal() { document.getElementById('modal-service').classList.remove('open'); editingServiceId = null; }

async function saveService() {
  const name          = document.getElementById('s-name').value.trim();
  const beschreibung  = document.getElementById('s-beschreibung').value.trim();
  const kategorie_id  = document.getElementById('s-kategorie').value;
  const einheit       = document.getElementById('s-einheit').value;
  const preisRaw      = document.getElementById('s-preis').value;
  const ist_aktiv     = document.getElementById('s-aktiv').value === 'true';
  const btn           = document.getElementById('s-save-btn');

  if (!name) { showToast('Bitte Name eingeben.', true); return; }
  if (!kategorie_id) { showToast('Bitte Kategorie auswählen.', true); return; }
  if (!einheit) { showToast('Bitte Einheit auswählen.', true); return; }

  const standardpreis = preisRaw === '' ? 0 : Number(preisRaw);
  if (Number.isNaN(standardpreis) || standardpreis < 0) { showToast('Preis muss eine Zahl ≥ 0 sein.', true); return; }

  btn.disabled = true;
  btn.textContent = editingServiceId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const payload = { name, beschreibung: beschreibung || null, kategorie_id, einheit, standardpreis, ist_aktiv };
    let error;
    if (editingServiceId) { ({ error } = await db.from('services').update(payload).eq('id', editingServiceId)); }
    else { ({ error } = await db.from('services').insert(payload)); }
    if (error) throw new Error(error.message);

    closeServiceModal();
    showToast(editingServiceId ? 'Leistung aktualisiert.' : 'Leistung angelegt.');
    await loadServices();
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingServiceId ? 'Speichern' : 'Anlegen';
  }
}

async function deleteService() {
  if (!editingServiceId) return;
  if (!confirm('Leistung wirklich löschen?\n\nHinweis: Wenn sie bereits in Einsätzen oder Terminen verwendet wird, solltest du sie stattdessen archivieren.')) return;

  const btn = document.getElementById('s-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const { error } = await db.from('services').delete().eq('id', editingServiceId);
    if (error) {
      if (error.message.toLowerCase().includes('foreign key') || error.code === '23503') {
        throw new Error('Diese Leistung wird noch in Einsätzen oder Terminen verwendet. Archiviere sie stattdessen.');
      }
      throw new Error(error.message);
    }
    closeServiceModal();
    showToast('Leistung gelöscht.');
    await loadServices();
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

// ═══════════════════════════════════════════════════════════
//  STAMMDATEN / LOOKUP-WERTE
// ═══════════════════════════════════════════════════════════

async function loadLookupKategorien() {
  const { data, error } = await db.from('lookup_values').select('kategorie').order('kategorie');
  if (error) { showToast('Fehler beim Laden der Kategorien: ' + error.message, true); return []; }
  return [...new Set((data || []).map(r => r.kategorie))];
}

async function loadLookupsPage() {
  const kategorien = await loadLookupKategorien();
  const select = document.getElementById('lookup-filter-kategorie');

  if (kategorien.length === 0) {
    select.innerHTML = '<option value="">— Keine Kategorien vorhanden —</option>';
  } else {
    const previous = select.value;
    select.innerHTML = kategorien.map(k => `<option value="${esc(k)}">${esc(k)}</option>`).join('');
    if (kategorien.includes(previous)) select.value = previous;
  }
  await loadLookups();
}

async function loadLookups() {
  const tbody = document.getElementById('lookups-table-body');
  const kategorie = document.getElementById('lookup-filter-kategorie').value;

  tbody.innerHTML = '<tr><td colspan="5"><div class="empty">Lade ...</div></td></tr>';
  if (!kategorie) { tbody.innerHTML = '<tr><td colspan="5"><div class="empty">Keine Kategorie ausgewählt.</div></td></tr>'; return; }

  const { data, error } = await db.from('lookup_values').select('*').eq('kategorie', kategorie).order('reihenfolge').order('wert');

  if (error) { tbody.innerHTML = `<tr><td colspan="5"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`; return; }
  if (!data || data.length === 0) { tbody.innerHTML = '<tr><td colspan="5"><div class="empty">Noch keine Einträge in dieser Kategorie.</div></td></tr>'; return; }

  tbody.innerHTML = data.map(lv => {
    const aktivBg  = lv.ist_aktiv ? '#f0fdf4' : '#f3f4f6';
    const aktivCol = lv.ist_aktiv ? '#16a34a' : '#6b7280';
    const aktivTxt = lv.ist_aktiv ? 'Aktiv' : 'Archiviert';
    return `
      <tr>
        <td><div class="cell-link" onclick="openLookupModal('edit', '${esc(lv.id)}')">${esc(lv.wert)}</div></td>
        <td>
          <span class="color-dot" style="background:${esc(lv.farbe || '#6b7280')}"></span>
          <span style="font-family:'SF Mono',Menlo,monospace;font-size:12px;color:var(--muted)">${esc(lv.farbe || '#6b7280')}</span>
        </td>
        <td style="color:var(--muted)">${esc(String(lv.reihenfolge ?? 0))}</td>
        <td><span class="badge" style="background:${aktivBg};color:${aktivCol}">${aktivTxt}</span></td>
        <td class="col-action" style="text-align:right"><button class="btn btn-sm" onclick="openLookupModal('edit', '${esc(lv.id)}')">Bearbeiten</button></td>
      </tr>`;
  }).join('');
}

async function openLookupModal(mode, lookupId = null) {
  if (!isAdmin()) { showToast('Du hast keine Berechtigung für diese Aktion.', true); return; }
  editingLookupId = lookupId;

  const kategorien = await loadLookupKategorien();
  const kSelect = document.getElementById('l-kategorie');
  let options = kategorien.map(k => `<option value="${esc(k)}">${esc(k)}</option>`).join('');
  options += '<option value="__new__">+ Neue Kategorie anlegen …</option>';
  kSelect.innerHTML = options;

  document.getElementById('l-new-kategorie-group').style.display = 'none';
  document.getElementById('l-new-kategorie').value = '';

  kSelect.onchange = () => {
    const isNew = kSelect.value === '__new__';
    document.getElementById('l-new-kategorie-group').style.display = isNew ? '' : 'none';
  };

  document.getElementById('l-wert').value = '';
  document.getElementById('l-farbe').value = '#6b7280';
  document.getElementById('l-reihenfolge').value = '0';
  document.getElementById('l-aktiv').value = 'true';

  if (mode === 'new') {
    document.getElementById('modal-lookup-title').textContent = 'Neuer Wert';
    document.getElementById('l-save-btn').textContent = 'Anlegen';
    document.getElementById('l-delete-btn').style.display = 'none';
    const filterKat = document.getElementById('lookup-filter-kategorie').value;
    if (filterKat && kategorien.includes(filterKat)) kSelect.value = filterKat;
  } else {
    document.getElementById('modal-lookup-title').textContent = 'Wert bearbeiten';
    document.getElementById('l-save-btn').textContent = 'Speichern';
    document.getElementById('l-delete-btn').style.display = 'block';

    const { data, error } = await db.from('lookup_values').select('*').eq('id', lookupId).single();
    if (error || !data) { showToast('Wert konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingLookupId = null; return; }

    kSelect.value = data.kategorie;
    document.getElementById('l-wert').value = data.wert || '';
    document.getElementById('l-farbe').value = data.farbe || '#6b7280';
    document.getElementById('l-reihenfolge').value = data.reihenfolge ?? 0;
    document.getElementById('l-aktiv').value = data.ist_aktiv ? 'true' : 'false';
  }

  document.getElementById('modal-lookup').classList.add('open');
  setTimeout(() => document.getElementById('l-wert').focus(), 100);
}

function closeLookupModal() { document.getElementById('modal-lookup').classList.remove('open'); editingLookupId = null; }

async function saveLookup() {
  const kSelect     = document.getElementById('l-kategorie');
  const isNew       = kSelect.value === '__new__';
  const kategorie   = isNew ? document.getElementById('l-new-kategorie').value.trim() : kSelect.value;
  const wert        = document.getElementById('l-wert').value.trim();
  const farbe       = document.getElementById('l-farbe').value;
  const reihenRaw   = document.getElementById('l-reihenfolge').value;
  const ist_aktiv   = document.getElementById('l-aktiv').value === 'true';
  const btn         = document.getElementById('l-save-btn');

  if (!kategorie) { showToast('Bitte Kategorie auswählen oder neue eingeben.', true); return; }
  if (isNew && !/^[a-z0-9_]+$/.test(kategorie)) { showToast('Kategorie-Schlüssel: nur Kleinbuchstaben, Zahlen und Unterstriche.', true); return; }
  if (!wert) { showToast('Bitte Wert eingeben.', true); return; }

  const reihenfolge = reihenRaw === '' ? 0 : parseInt(reihenRaw, 10);
  if (Number.isNaN(reihenfolge)) { showToast('Reihenfolge muss eine Zahl sein.', true); return; }

  btn.disabled = true;
  btn.textContent = editingLookupId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const payload = { kategorie, wert, farbe, reihenfolge, ist_aktiv };
    let error;
    if (editingLookupId) { ({ error } = await db.from('lookup_values').update(payload).eq('id', editingLookupId)); }
    else { ({ error } = await db.from('lookup_values').insert(payload)); }
    if (error) throw new Error(error.message);

    closeLookupModal();
    showToast(editingLookupId ? 'Wert aktualisiert.' : 'Wert angelegt.');
    await loadLookupsPage();
    const filterSelect = document.getElementById('lookup-filter-kategorie');
    if ([...filterSelect.options].some(o => o.value === kategorie)) { filterSelect.value = kategorie; await loadLookups(); }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingLookupId ? 'Speichern' : 'Anlegen';
  }
}

async function deleteLookup() {
  if (!editingLookupId) return;
  if (!confirm('Wert wirklich löschen?\n\nFalls dieser Wert bereits an anderen Stellen referenziert wird, wird das Löschen vom System verhindert. In dem Fall bitte stattdessen archivieren.')) return;

  const btn = document.getElementById('l-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const { error } = await db.from('lookup_values').delete().eq('id', editingLookupId);
    if (error) {
      if (error.message.toLowerCase().includes('foreign key') || error.code === '23503') {
        throw new Error('Dieser Wert wird noch an anderer Stelle verwendet. Archiviere ihn stattdessen.');
      }
      throw new Error(error.message);
    }
    closeLookupModal();
    showToast('Wert gelöscht.');
    await loadLookupsPage();
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

// ═══════════════════════════════════════════════════════════
//  FIRMEN (COMPANIES)
// ═══════════════════════════════════════════════════════════

async function loadUnternehmensTypen() {
  const { data, error } = await db.from('lookup_values')
    .select('id, wert, farbe').eq('kategorie', 'unternehmens_typ').eq('ist_aktiv', true).order('reihenfolge');
  if (error) { showToast('Fehler beim Laden der Firmentypen: ' + error.message, true); return []; }
  return data || [];
}

/**
 * Baut eine Map {companyId → {next, last}} basierend auf allen Terminen.
 * `next`: nächster kommender (ab heute), falls vorhanden
 * `last`: letzter vergangener, falls vorhanden
 */
async function loadCompanyAppointmentMap() {
  const { data, error } = await db.from('appointments')
    .select('id, company_id, datum, titel, status, uhrzeit_von')
    .not('company_id', 'is', null);

  if (error) { companyAppointmentMap = {}; return; }

  const todayISO = toISODate(new Date());
  const map = {};

  (data || []).forEach(a => {
    if (!a.company_id) return;
    if (!map[a.company_id]) map[a.company_id] = { next: null, last: null };

    if (a.datum >= todayISO) {
      // Kandidat für "next": das früheste zukünftige Datum
      const current = map[a.company_id].next;
      if (!current || a.datum < current.datum ||
          (a.datum === current.datum && (a.uhrzeit_von || '') < (current.uhrzeit_von || ''))) {
        map[a.company_id].next = a;
      }
    } else {
      // Kandidat für "last": das jüngste vergangene Datum
      const current = map[a.company_id].last;
      if (!current || a.datum > current.datum ||
          (a.datum === current.datum && (a.uhrzeit_von || '') > (current.uhrzeit_von || ''))) {
        map[a.company_id].last = a;
      }
    }
  });

  companyAppointmentMap = map;
}

async function loadCompanies() {
  const tbody = document.getElementById('companies-table-body');
  tbody.innerHTML = '<tr><td colspan="7"><div class="empty">Lade Firmen ...</div></td></tr>';

  const typSelect = document.getElementById('companies-typ-filter');
  if (typSelect.options.length <= 1) {
    const typen = await loadUnternehmensTypen();
    typSelect.innerHTML = '<option value="">Alle Typen</option>'
      + typen.map(t => `<option value="${esc(t.id)}">${esc(t.wert)}</option>`).join('');
  }

  const [companiesResult, contactsResult] = await Promise.all([
    db.from('companies').select('*, typ:lookup_values!companies_typ_id_fkey(id, wert, farbe)').order('name'),
    db.from('contacts').select('id, vorname, nachname, company_id, email, telefon').not('company_id', 'is', null),
    loadCompanyAppointmentMap()
  ]);

  const { data, error } = companiesResult;

  // companyContactsMap aus allen Kontakten befüllen
  companyContactsMap = {};
  (contactsResult.data || []).forEach(k => {
    if (!k.company_id) return;
    if (!companyContactsMap[k.company_id]) companyContactsMap[k.company_id] = [];
    companyContactsMap[k.company_id].push(k);
  });
  // Sortieren pro Firma
  Object.keys(companyContactsMap).forEach(cid => {
    companyContactsMap[cid].sort((a, b) => (a.nachname || '').localeCompare(b.nachname || ''));
  });

  if (error) { tbody.innerHTML = `<tr><td colspan="7"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`; return; }

  companiesCache = data || [];
  filterCompanies();
}

function filterCompanies() {
  const searchTerm = document.getElementById('companies-search').value.trim().toLowerCase();
  const typFilter  = document.getElementById('companies-typ-filter').value;

  let filtered = companiesCache;
  if (typFilter) filtered = filtered.filter(c => c.typ_id === typFilter);
  if (searchTerm) {
    filtered = filtered.filter(c => {
      const haystack = [c.name, c.stadt, c.plz, c.email, c.telefon, c.branche, c.strasse, c.website]
        .filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(searchTerm);
    });
  }
  renderCompaniesTable(filtered);
}

/** Rendert die Termin-Zelle für die Firmen-Liste */
function renderNextAppointmentCell(companyId) {
  const entry = companyAppointmentMap[companyId];
  if (!entry || (!entry.next && !entry.last)) {
    return '<span style="color:var(--muted);font-style:italic;font-size:12px">—</span>';
  }

  // Prio: nächster Termin, wenn vorhanden
  if (entry.next) {
    return `
      <div class="next-appt">
        <div class="next-appt-label" style="color:var(--link)">Nächster</div>
        <div class="next-appt-date upcoming">${esc(formatDateCompact(entry.next.datum))}</div>
        <div class="next-appt-title" title="${esc(entry.next.titel || '')}">${esc(entry.next.titel || '')}</div>
      </div>`;
  }

  // Sonst: letzter vergangener
  return `
    <div class="next-appt">
      <div class="next-appt-label">Letzter</div>
      <div class="next-appt-date past">${esc(formatDateCompact(entry.last.datum))}</div>
      <div class="next-appt-title" title="${esc(entry.last.titel || '')}">${esc(entry.last.titel || '')}</div>
    </div>`;
}

function renderCompaniesTable(companies) {
  const tbody = document.getElementById('companies-table-body');
  const countEl = document.getElementById('companies-count');

  const total = companiesCache.length;
  const shown = companies.length;
  countEl.textContent = (shown === total)
    ? `${total} Firma${total === 1 ? '' : 'n'}`
    : `${shown} von ${total} Firmen`;

  if (shown === 0) {
    const msg = total === 0
      ? 'Noch keine Firmen angelegt. Klicke oben auf „+ Neue Firma".'
      : 'Keine Firmen entsprechen den Filterkriterien.';
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty">${msg}</div></td></tr>`;
    return;
  }

  tbody.innerHTML = companies.map(c => {
    const typFarbe = c.typ?.farbe || '#6b7280';
    const typWert  = c.typ?.wert || '—';
    const ort = [c.plz, c.stadt].filter(Boolean).join(' ');

    return `
      <tr>
        <td>
          <div class="cell-link" onclick="navigateTo('firma', '${esc(c.id)}')">${esc(c.name)}</div>
          ${c.website ? `<div style="font-size:11px;color:var(--muted);margin-top:2px">${esc(c.website)}</div>` : ''}
        </td>
        <td>
          <span class="badge" style="background:${esc(typFarbe)}22;color:${esc(typFarbe)}">${esc(typWert)}</span>
        </td>
        <td class="col-tablet" style="color:var(--muted)">${esc(ort || '—')}</td>
        <td class="col-tablet" style="color:var(--muted)">${esc(c.telefon || '—')}</td>
        <td class="col-desktop" style="color:var(--muted)">${esc(c.branche || '—')}</td>
        <td class="col-desktop">${renderNextAppointmentCell(c.id)}</td>
        <td class="col-action" style="text-align:right">
          <div class="btn-row" style="justify-content:flex-end">
            <button class="btn-copy" onclick="copyCompanyById('${esc(c.id)}')" title="Firmendaten kopieren" aria-label="Firmendaten kopieren">
              ${COPY_ICON_SVG}
            </button>
            <button class="btn btn-sm" onclick="navigateTo('firma', '${esc(c.id)}')">Details</button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

async function openCompanyModal(mode, companyId = null) {
  editingCompanyId = companyId;

  const typSelect = document.getElementById('c-typ');
  const typen = await loadUnternehmensTypen();
  if (typen.length === 0) {
    typSelect.innerHTML = '<option value="">Keine Typen – bitte erst unter „Stammdaten" anlegen</option>';
  } else {
    typSelect.innerHTML = typen.map(t => `<option value="${esc(t.id)}">${esc(t.wert)}</option>`).join('');
  }

  document.getElementById('c-name').value = '';
  document.getElementById('c-branche').value = '';
  document.getElementById('c-strasse').value = '';
  document.getElementById('c-plz').value = '';
  document.getElementById('c-stadt').value = '';
  document.getElementById('c-land').value = 'Deutschland';
  document.getElementById('c-telefon').value = '';
  document.getElementById('c-email').value = '';
  document.getElementById('c-website').value = '';
  document.getElementById('c-notizen').value = '';

  if (mode === 'new') {
    document.getElementById('modal-company-title').textContent = 'Neue Firma';
    document.getElementById('c-save-btn').textContent = 'Anlegen';
    document.getElementById('c-delete-btn').style.display = 'none';
  } else {
    document.getElementById('modal-company-title').textContent = 'Firma bearbeiten';
    document.getElementById('c-save-btn').textContent = 'Speichern';
    document.getElementById('c-delete-btn').style.display = 'block';

    const { data, error } = await db.from('companies').select('*').eq('id', companyId).single();
    if (error || !data) { showToast('Firma konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingCompanyId = null; return; }

    document.getElementById('c-name').value = data.name || '';
    document.getElementById('c-branche').value = data.branche || '';
    document.getElementById('c-strasse').value = data.strasse || '';
    document.getElementById('c-plz').value = data.plz || '';
    document.getElementById('c-stadt').value = data.stadt || '';
    document.getElementById('c-land').value = data.land || 'Deutschland';
    document.getElementById('c-telefon').value = data.telefon || '';
    document.getElementById('c-email').value = data.email || '';
    document.getElementById('c-website').value = data.website || '';
    document.getElementById('c-notizen').value = data.notizen || '';
    if (data.typ_id) typSelect.value = data.typ_id;
  }

  document.getElementById('modal-company').classList.add('open');
  setTimeout(() => document.getElementById('c-name').focus(), 100);
}

function closeCompanyModal() { document.getElementById('modal-company').classList.remove('open'); editingCompanyId = null; }

async function saveCompany() {
  const name     = document.getElementById('c-name').value.trim();
  const typ_id   = document.getElementById('c-typ').value;
  const branche  = document.getElementById('c-branche').value.trim();
  const strasse  = document.getElementById('c-strasse').value.trim();
  const plz      = document.getElementById('c-plz').value.trim();
  const stadt    = document.getElementById('c-stadt').value.trim();
  const land     = document.getElementById('c-land').value.trim();
  const telefon  = document.getElementById('c-telefon').value.trim();
  const email    = document.getElementById('c-email').value.trim();
  const website  = document.getElementById('c-website').value.trim();
  const notizen  = document.getElementById('c-notizen').value.trim();
  const btn      = document.getElementById('c-save-btn');

  if (!name) { showToast('Bitte Name eingeben.', true); return; }
  if (!typ_id) { showToast('Bitte Typ auswählen.', true); return; }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showToast('E-Mail-Adresse sieht nicht korrekt aus.', true);
    return;
  }

  btn.disabled = true;
  btn.textContent = editingCompanyId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const payload = {
      name, typ_id,
      branche: branche || null, strasse: strasse || null, plz: plz || null,
      stadt: stadt || null, land: land || 'Deutschland',
      telefon: telefon || null, email: email || null,
      website: website || null, notizen: notizen || null
    };
    if (!editingCompanyId) payload.erstellt_von = currentUser?.id || null;

    const savedId = editingCompanyId;

    let error;
    if (editingCompanyId) { ({ error } = await db.from('companies').update(payload).eq('id', editingCompanyId)); }
    else { ({ error } = await db.from('companies').insert(payload)); }
    if (error) throw new Error(error.message);

    closeCompanyModal();
    showToast(savedId ? 'Firma aktualisiert.' : 'Firma angelegt.');

    if (savedId && currentCompanyDetailId === savedId) {
      await loadCompanyDetail(savedId);
    } else {
      await loadCompanies();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingCompanyId ? 'Speichern' : 'Anlegen';
  }
}

async function deleteCompany() {
  if (!editingCompanyId) return;
  if (!confirm('Firma wirklich löschen?\n\nHinweis: Wenn bereits Kontakte, Projekte oder Einsätze mit dieser Firma verknüpft sind, wird das Löschen vom System verhindert.')) return;

  const btn = document.getElementById('c-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const deletedId = editingCompanyId;
    const { error } = await db.from('companies').delete().eq('id', deletedId);
    if (error) {
      if (error.message.toLowerCase().includes('foreign key') || error.code === '23503') {
        throw new Error('Diese Firma hat noch verknüpfte Kontakte, Projekte oder Einsätze. Diese müssen zuerst entfernt werden.');
      }
      throw new Error(error.message);
    }
    closeCompanyModal();
    showToast('Firma gelöscht.');

    if (currentCompanyDetailId === deletedId) {
      currentCompanyDetailId = null;
      navigateTo('companies');
    } else {
      await loadCompanies();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

// ═══════════════════════════════════════════════════════════
//  FIRMEN-DETAILSEITE
// ═══════════════════════════════════════════════════════════

async function loadCompanyDetail(companyId) {
  currentCompanyDetailId = companyId;

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-company-detail').classList.add('active');
  document.querySelectorAll('.nav-item:not(.nav-item-group)').forEach(b => b.classList.remove('active'));
  document.getElementById('nav-companies')?.classList.add('active');
  setMobileNav('company-detail');

  document.getElementById('company-detail-name').textContent = '…';
  document.getElementById('company-detail-title').textContent = '…';
  document.getElementById('company-detail-subline').innerHTML = '';
  document.getElementById('company-detail-info').innerHTML = '<div style="color:var(--muted);font-size:13px">Lade Firma ...</div>';
  document.getElementById('company-detail-notizen-wrap').style.display = 'none';
  document.getElementById('company-contacts-body').innerHTML = '<tr><td colspan="5"><div class="empty">Lade Kontakte ...</div></td></tr>';
  document.getElementById('company-appointments-body').innerHTML = '<tr><td colspan="7"><div class="empty">Lade Termine ...</div></td></tr>';
  document.getElementById('company-appointments-show-all').style.display = 'none';
  document.getElementById('company-projects-body').innerHTML = '<tr><td colspan="6"><div class="empty">Lade Projekte ...</div></td></tr>';

  const { data, error } = await db.from('companies')
    .select('*, typ:lookup_values!companies_typ_id_fkey(id, wert, farbe)')
    .eq('id', companyId).single();

  if (error || !data) {
    document.getElementById('company-detail-info').innerHTML = `<div style="color:var(--danger);font-size:13px">Firma nicht gefunden oder Fehler: ${esc(error?.message || 'Unbekannt')}</div>`;
    document.getElementById('company-detail-title').textContent = 'Fehler';
    document.getElementById('company-detail-name').textContent = 'Fehler';
    return;
  }

  renderCompanyDetail(data);
  await loadCompanyContacts(companyId);
  await loadCompanyAppointments(companyId);
  await loadCompanyProjects(companyId);
  await loadCompanyDeployments(companyId);
}

function renderCompanyDetail(c) {
  document.getElementById('company-detail-name').textContent = c.name;
  document.getElementById('company-detail-title').textContent = c.name;

  const typFarbe = c.typ?.farbe || '#6b7280';
  const typWert  = c.typ?.wert || '—';
  const subline = document.getElementById('company-detail-subline');
  subline.innerHTML = `
    <span class="badge" style="background:${esc(typFarbe)}22;color:${esc(typFarbe)}">${esc(typWert)}</span>
    ${c.branche ? `<span>· ${esc(c.branche)}</span>` : ''}
  `;

  const editBtn = document.getElementById('company-detail-edit-btn');
  editBtn.onclick = () => openCompanyModal('edit', c.id);

  const copyBtn = document.getElementById('company-detail-copy-btn');
  copyBtn.onclick = () => copyCompanyById(c.id);

  document.getElementById('company-detail-add-contact-btn').onclick = () => {
    contactModalPrefillCompanyId = c.id;
    openContactModal('new');
  };

  document.getElementById('company-detail-add-appointment-btn').onclick = () => {
    appointmentModalPrefillCompanyId = c.id;
    openAppointmentModal('new');
  };

  document.getElementById('company-detail-add-project-btn').onclick = () => {
    projectModalPrefillCompanyId = c.id;
    openProjectModal('new');
  };

  document.getElementById('company-detail-add-deployment-btn').onclick = () => {
    deploymentModalPrefillCompanyId = c.id;
    openDeploymentModal('new');
  };

  const info = document.getElementById('company-detail-info');
  const adrLines = [];
  if (c.strasse) adrLines.push(c.strasse);
  const ort = [c.plz, c.stadt].filter(Boolean).join(' ');
  if (ort) adrLines.push(ort);
  if (c.land && c.land !== 'Deutschland') adrLines.push(c.land);
  const adrHtml = adrLines.length > 0
    ? adrLines.map(l => esc(l)).join('<br>')
    : '<span class="detail-value-muted">—</span>';

  const telHtml = c.telefon
    ? `<a href="tel:${esc(c.telefon)}">${esc(c.telefon)}</a>`
    : '<span class="detail-value-muted">—</span>';
  const mailHtml = c.email
    ? `<a href="mailto:${esc(c.email)}">${esc(c.email)}</a>`
    : '<span class="detail-value-muted">—</span>';
  let websiteHtml;
  if (c.website) {
    const url = c.website.startsWith('http') ? c.website : `https://${c.website}`;
    websiteHtml = `<a href="${esc(url)}" target="_blank" rel="noopener">${esc(c.website)}</a>`;
  } else {
    websiteHtml = '<span class="detail-value-muted">—</span>';
  }

  info.innerHTML = `
    <div class="detail-field">
      <div class="detail-label">Adresse</div>
      <div class="detail-value">${adrHtml}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Website</div>
      <div class="detail-value">${websiteHtml}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Telefon</div>
      <div class="detail-value">${telHtml}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">E-Mail</div>
      <div class="detail-value">${mailHtml}</div>
    </div>
  `;

  if (c.notizen) {
    document.getElementById('company-detail-notizen-wrap').style.display = '';
    document.getElementById('company-detail-notizen').textContent = c.notizen;
  } else {
    document.getElementById('company-detail-notizen-wrap').style.display = 'none';
  }
}

async function loadCompanyContacts(companyId) {
  const tbody = document.getElementById('company-contacts-body');
  const countEl = document.getElementById('company-contacts-count');

  const { data, error } = await db.from('contacts')
    .select('*').eq('company_id', companyId).order('nachname').order('vorname');

  if (error) {
    tbody.innerHTML = `<tr><td colspan="5"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Kontakte';
    return;
  }

  // Cache aktualisieren für sync-Copy
  companyContactsMap[companyId] = data || [];

  // Für die companiesCache-Lookup-Kompatibilität: Firma ins companiesCache pushen falls leer
  if (companiesCache.length === 0) {
    const { data: c } = await db.from('companies').select('*').eq('id', companyId).single();
    if (c) companiesCache = [c];
  }

  const total = (data || []).length;
  countEl.textContent = total === 0 ? 'Keine Kontakte' : `${total} Kontakt${total === 1 ? '' : 'e'}`;

  if (total === 0) {
    tbody.innerHTML = '<tr><td colspan="5"><div class="empty">Noch keine Kontakte für diese Firma. Klicke oben auf „+ Kontakt hinzufügen".</div></td></tr>';
    return;
  }

  tbody.innerHTML = data.map(k => {
    const fullName = [k.vorname, k.nachname].filter(Boolean).join(' ');
    return `
      <tr>
        <td><div class="cell-link" onclick="navigateTo('kontakt', '${esc(k.id)}')">${esc(fullName)}</div></td>
        <td class="col-tablet" style="color:var(--muted)">${esc(k.position || '—')}</td>
        <td class="col-tablet" style="color:var(--muted)">${esc(k.telefon || '—')}</td>
        <td class="col-desktop" style="color:var(--muted)">${esc(k.email || '—')}</td>
        <td class="col-action" style="text-align:right">
          <div class="btn-row" style="justify-content:flex-end">
            <button class="btn-copy" onclick="copyContactById('${esc(k.id)}')" title="Kontakt kopieren" aria-label="Kontakt kopieren">${COPY_ICON_SVG}</button>
            <button class="btn btn-sm" onclick="openContactModal('edit', '${esc(k.id)}')">Bearbeiten</button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

async function loadCompanyAppointments(companyId) {
  const tbody = document.getElementById('company-appointments-body');
  const countEl = document.getElementById('company-appointments-count');
  const showAllWrap = document.getElementById('company-appointments-show-all');
  const showAllLink = document.getElementById('company-appointments-show-all-link');

  const { data, error } = await db.from('appointments')
    .select('*, typ:lookup_values!appointments_typ_id_fkey(id, wert, farbe), contact:contacts(id, vorname, nachname)')
    .eq('company_id', companyId);

  if (error) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Termine';
    showAllWrap.style.display = 'none';
    return;
  }

  const all = data || [];
  const total = all.length;
  const anzGeplant       = all.filter(a => a.status === 'geplant').length;
  const anzDurchgefuehrt = all.filter(a => a.status === 'durchgefuehrt').length;

  if (total === 0) {
    countEl.textContent = 'Keine Termine';
    tbody.innerHTML = '<tr><td colspan="7"><div class="empty">Noch keine Termine für diese Firma. Klicke oben auf „+ Termin hinzufügen".</div></td></tr>';
    showAllWrap.style.display = 'none';
    return;
  }

  countEl.textContent = `${total} Termin${total === 1 ? '' : 'e'} · ${anzGeplant} geplant · ${anzDurchgefuehrt} durchgeführt`;

  // Sortieren: kommende aufsteigend, dann vergangene absteigend
  const todayISO = toISODate(new Date());
  const upcoming = all.filter(a => a.datum >= todayISO)
    .sort((a, b) => a.datum === b.datum
      ? (a.uhrzeit_von || '').localeCompare(b.uhrzeit_von || '')
      : a.datum.localeCompare(b.datum));
  const past = all.filter(a => a.datum < todayISO)
    .sort((a, b) => a.datum === b.datum
      ? (b.uhrzeit_von || '').localeCompare(a.uhrzeit_von || '')
      : b.datum.localeCompare(a.datum));

  const sorted = upcoming.concat(past);
  const toShow = sorted.slice(0, 10);
  const hasMore = sorted.length > 10;

  tbody.innerHTML = toShow.map(a => {
    const typFarbe = a.typ?.farbe || '#6b7280';
    const typWert  = a.typ?.wert || '—';
    const isPast = a.datum < todayISO;
    const kontaktName = a.contact
      ? [a.contact.vorname, a.contact.nachname].filter(Boolean).join(' ')
      : '';

    const uhrzeit = a.uhrzeit_von
      ? (a.uhrzeit_bis ? `${formatTime(a.uhrzeit_von)}–${formatTime(a.uhrzeit_bis)}` : formatTime(a.uhrzeit_von))
      : '';

    return `
      <tr>
        <td>
          <div class="date-cell${isPast ? ' past' : ''}">${esc(formatDateDE(a.datum))}</div>
        </td>
        <td class="col-tablet" style="color:var(--muted)">${esc(uhrzeit || '—')}</td>
        <td>
          <div class="cell-link" onclick="openAppointmentModal('edit', '${esc(a.id)}')">${esc(a.titel || '—')}</div>
        </td>
        <td class="col-tablet">
          <span class="badge" style="background:${esc(typFarbe)}22;color:${esc(typFarbe)}">${esc(typWert)}</span>
        </td>
        <td class="col-desktop" style="color:var(--muted)">${esc(kontaktName || '—')}</td>
        <td>
          <span class="badge" style="background:${appointmentStatusBg(a.status)};color:${appointmentStatusColor(a.status)}">${esc(appointmentStatusLabel(a.status))}</span>
        </td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="openAppointmentModal('edit', '${esc(a.id)}')">Bearbeiten</button>
        </td>
      </tr>`;
  }).join('');

  if (hasMore) {
    showAllLink.onclick = () => navigateTo('appointments', { firma: companyId });
    showAllLink.textContent = `Alle ${total} Termine dieser Firma anzeigen →`;
    showAllWrap.style.display = '';
  } else {
    showAllWrap.style.display = 'none';
  }
}

// ═══════════════════════════════════════════════════════════
//  KONTAKTE (CONTACTS)
// ═══════════════════════════════════════════════════════════

async function loadContacts() {
  const tbody = document.getElementById('contacts-table-body');
  tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Lade Kontakte ...</div></td></tr>';

  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name').order('name');
    companiesCache = cs || [];
  }

  const companyFilter = document.getElementById('contacts-company-filter');
  const existingValue = companyFilter.value;
  companyFilter.innerHTML = '<option value="">Alle Firmen</option><option value="__none__">Ohne Firmenzuordnung</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  if (existingValue) companyFilter.value = existingValue;

  const { data, error } = await db.from('contacts')
    .select('*, company:companies(id, name)').order('nachname').order('vorname');

  if (error) { tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`; return; }

  contactsCache = data || [];

  // Sync-Copy-Cache aktualisieren
  companyContactsMap = {};
  contactsCache.forEach(k => {
    if (!k.company_id) return;
    if (!companyContactsMap[k.company_id]) companyContactsMap[k.company_id] = [];
    companyContactsMap[k.company_id].push(k);
  });

  filterContacts();
}

function filterContacts() {
  const searchTerm = document.getElementById('contacts-search').value.trim().toLowerCase();
  const companyFilterVal = document.getElementById('contacts-company-filter').value;

  let filtered = contactsCache;
  if (companyFilterVal === '__none__') {
    filtered = filtered.filter(k => !k.company_id);
  } else if (companyFilterVal) {
    filtered = filtered.filter(k => k.company_id === companyFilterVal);
  }
  if (searchTerm) {
    filtered = filtered.filter(k => {
      const haystack = [k.vorname, k.nachname, k.position, k.email, k.telefon, k.company?.name]
        .filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(searchTerm);
    });
  }
  renderContactsTable(filtered);
}

function renderContactsTable(contacts) {
  const tbody = document.getElementById('contacts-table-body');
  const countEl = document.getElementById('contacts-count');

  const total = contactsCache.length;
  const shown = contacts.length;
  countEl.textContent = (shown === total)
    ? `${total} Kontakt${total === 1 ? '' : 'e'}`
    : `${shown} von ${total} Kontakten`;

  if (shown === 0) {
    const msg = total === 0
      ? 'Noch keine Kontakte angelegt. Klicke oben auf „+ Neuer Kontakt".'
      : 'Keine Kontakte entsprechen den Filterkriterien.';
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">${msg}</div></td></tr>`;
    return;
  }

  tbody.innerHTML = contacts.map(k => {
    const fullName = [k.vorname, k.nachname].filter(Boolean).join(' ');
    const firmaHtml = k.company_id && k.company
      ? `<div class="cell-link" onclick="navigateTo('firma', '${esc(k.company_id)}')">${esc(k.company.name)}</div>`
      : '<span style="color:var(--muted);font-style:italic">Ohne Firma</span>';

    return `
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div class="avatar">${esc(ini(fullName))}</div>
            <div class="cell-link" onclick="navigateTo('kontakt', '${esc(k.id)}')">${esc(fullName)}</div>
          </div>
        </td>
        <td>${firmaHtml}</td>
        <td class="col-tablet" style="color:var(--muted)">${esc(k.position || '—')}</td>
        <td class="col-tablet" style="color:var(--muted)">${esc(k.telefon || '—')}</td>
        <td class="col-desktop" style="color:var(--muted)">${esc(k.email || '—')}</td>
        <td class="col-action" style="text-align:right">
          <div class="btn-row" style="justify-content:flex-end">
            <button class="btn-copy" onclick="copyContactById('${esc(k.id)}')" title="Kontakt kopieren" aria-label="Kontakt kopieren">${COPY_ICON_SVG}</button>
            <button class="btn btn-sm" onclick="openContactModal('edit', '${esc(k.id)}')">Bearbeiten</button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

async function openContactModal(mode, contactId = null) {
  editingContactId = contactId;

  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name').order('name');
    companiesCache = cs || [];
  }
  const companySelect = document.getElementById('k-company');
  companySelect.innerHTML = '<option value="">— Keine Firma —</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');

  document.getElementById('k-vorname').value = '';
  document.getElementById('k-nachname').value = '';
  document.getElementById('k-position').value = '';
  document.getElementById('k-telefon').value = '';
  document.getElementById('k-email').value = '';
  document.getElementById('k-notizen').value = '';
  companySelect.value = '';

  if (mode === 'new') {
    document.getElementById('modal-contact-title').textContent = 'Neuer Kontakt';
    document.getElementById('k-save-btn').textContent = 'Anlegen';
    document.getElementById('k-delete-btn').style.display = 'none';

    if (contactModalPrefillCompanyId) {
      companySelect.value = contactModalPrefillCompanyId;
      contactModalPrefillCompanyId = null;
    }
  } else {
    document.getElementById('modal-contact-title').textContent = 'Kontakt bearbeiten';
    document.getElementById('k-save-btn').textContent = 'Speichern';
    document.getElementById('k-delete-btn').style.display = 'block';

    const { data, error } = await db.from('contacts').select('*').eq('id', contactId).single();
    if (error || !data) { showToast('Kontakt konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingContactId = null; return; }

    document.getElementById('k-vorname').value = data.vorname || '';
    document.getElementById('k-nachname').value = data.nachname || '';
    document.getElementById('k-position').value = data.position || '';
    document.getElementById('k-telefon').value = data.telefon || '';
    document.getElementById('k-email').value = data.email || '';
    document.getElementById('k-notizen').value = data.notizen || '';
    if (data.company_id) companySelect.value = data.company_id;
  }

  document.getElementById('modal-contact').classList.add('open');
  setTimeout(() => document.getElementById('k-vorname').focus(), 100);
}

function closeContactModal() {
  document.getElementById('modal-contact').classList.remove('open');
  editingContactId = null;
  contactModalPrefillCompanyId = null;
}

async function saveContact() {
  const vorname    = document.getElementById('k-vorname').value.trim();
  const nachname   = document.getElementById('k-nachname').value.trim();
  const position   = document.getElementById('k-position').value.trim();
  const company_id = document.getElementById('k-company').value || null;
  const telefon    = document.getElementById('k-telefon').value.trim();
  const email      = document.getElementById('k-email').value.trim();
  const notizen    = document.getElementById('k-notizen').value.trim();
  const btn        = document.getElementById('k-save-btn');

  if (!vorname) { showToast('Bitte Vorname eingeben.', true); return; }
  if (!nachname) { showToast('Bitte Nachname eingeben.', true); return; }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { showToast('E-Mail-Adresse sieht nicht korrekt aus.', true); return; }

  btn.disabled = true;
  btn.textContent = editingContactId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const payload = {
      vorname, nachname,
      position: position || null, company_id,
      telefon: telefon || null, email: email || null,
      notizen: notizen || null
    };
    if (!editingContactId) payload.erstellt_von = currentUser?.id || null;

    let error;
    if (editingContactId) { ({ error } = await db.from('contacts').update(payload).eq('id', editingContactId)); }
    else { ({ error } = await db.from('contacts').insert(payload)); }
    if (error) throw new Error(error.message);

    closeContactModal();
    showToast(editingContactId ? 'Kontakt aktualisiert.' : 'Kontakt angelegt.');

    const savedId = editingContactId;
    if (savedId && currentContactDetailId === savedId && document.getElementById('page-contact-detail').classList.contains('active')) {
      await loadContactDetail(savedId);
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await loadCompanyContacts(currentCompanyDetailId);
    } else {
      await loadContacts();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingContactId ? 'Speichern' : 'Anlegen';
  }
}

async function deleteContact() {
  if (!editingContactId) return;
  if (!confirm('Kontakt wirklich löschen?')) return;

  const btn = document.getElementById('k-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const deletedId = editingContactId;
    const { error } = await db.from('contacts').delete().eq('id', deletedId);
    if (error) throw new Error(error.message);

    closeContactModal();
    showToast('Kontakt gelöscht.');

    if (currentContactDetailId === deletedId) {
      currentContactDetailId = null;
      navigateTo('contacts');
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await loadCompanyContacts(currentCompanyDetailId);
    } else {
      await loadContacts();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

// ═══════════════════════════════════════════════════════════
//  TERMINE (APPOINTMENTS)
// ═══════════════════════════════════════════════════════════

async function loadTerminTypen() {
  if (terminTypenCache.length > 0) return terminTypenCache;
  const { data, error } = await db.from('lookup_values')
    .select('id, wert, farbe').eq('kategorie', 'termin_typ').eq('ist_aktiv', true).order('reihenfolge');
  if (error) { showToast('Fehler beim Laden der Termintypen: ' + error.message, true); return []; }
  terminTypenCache = data || [];
  return terminTypenCache;
}

async function loadAppointments() {
  const tbody = document.getElementById('appointments-table-body');
  tbody.innerHTML = '<tr><td colspan="8"><div class="empty">Lade Termine ...</div></td></tr>';

  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name').order('name');
    companiesCache = cs || [];
  }

  // Firma-Filter-Dropdown befüllen
  const companyFilter = document.getElementById('appointments-company-filter');
  const existingCompanyValue = companyFilter.value;
  companyFilter.innerHTML = '<option value="">Alle Firmen</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  if (existingCompanyValue) companyFilter.value = existingCompanyValue;

  // Termintyp-Filter-Dropdown befüllen
  const typen = await loadTerminTypen();
  const typFilter = document.getElementById('appointments-typ-filter');
  if (typFilter.options.length <= 1) {
    typFilter.innerHTML = '<option value="">Alle Typen</option>'
      + typen.map(t => `<option value="${esc(t.id)}">${esc(t.wert)}</option>`).join('');
  }

  // Pending-Filter aus URL-Parameter anwenden
  if (pendingAppointmentsFilter?.firma) {
    companyFilter.value = pendingAppointmentsFilter.firma;
    pendingAppointmentsFilter = null;
  }

  const { data, error } = await db.from('appointments')
    .select('*, typ:lookup_values!appointments_typ_id_fkey(id, wert, farbe), company:companies(id, name), contact:contacts(id, vorname, nachname)')
    .order('datum', { ascending: false }).order('uhrzeit_von', { ascending: false });

  if (error) { tbody.innerHTML = `<tr><td colspan="8"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`; return; }

  appointmentsCache = data || [];
  filterAppointments();
}

function filterAppointments() {
  const searchTerm  = document.getElementById('appointments-search').value.trim().toLowerCase();
  const rangeFilter = document.getElementById('appointments-range-filter').value;
  const companyFilterVal = document.getElementById('appointments-company-filter').value;
  const statusFilter = document.getElementById('appointments-status-filter').value;
  const typFilter   = document.getElementById('appointments-typ-filter').value;

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todayISO = toISODate(today);

  let filtered = appointmentsCache;

  // Range-Filter
  if (rangeFilter === 'today') {
    filtered = filtered.filter(a => a.datum === todayISO);
  } else if (rangeFilter === 'week') {
    const weekStart = new Date(today);
    const day = weekStart.getDay();
    const diff = (day === 0 ? -6 : 1 - day);
    weekStart.setDate(weekStart.getDate() + diff);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);
    const startISO = toISODate(weekStart);
    const endISO   = toISODate(weekEnd);
    filtered = filtered.filter(a => a.datum >= startISO && a.datum <= endISO);
  } else if (rangeFilter === 'month') {
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const monthEnd   = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    const startISO = toISODate(monthStart);
    const endISO   = toISODate(monthEnd);
    filtered = filtered.filter(a => a.datum >= startISO && a.datum <= endISO);
  } else if (rangeFilter === 'upcoming') {
    filtered = filtered.filter(a => a.datum >= todayISO);
  } else if (rangeFilter === 'past') {
    filtered = filtered.filter(a => a.datum < todayISO);
  }

  // Firma-Filter
  if (companyFilterVal) filtered = filtered.filter(a => a.company_id === companyFilterVal);

  // Status-Filter
  if (statusFilter) filtered = filtered.filter(a => a.status === statusFilter);

  // Typ-Filter
  if (typFilter) filtered = filtered.filter(a => a.typ_id === typFilter);

  // Such-Filter
  if (searchTerm) {
    filtered = filtered.filter(a => {
      const haystack = [a.titel, a.ort, a.notizen, a.company?.name,
                        a.contact ? [a.contact.vorname, a.contact.nachname].filter(Boolean).join(' ') : '']
        .filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(searchTerm);
    });
  }

  // Sortierung: für upcoming/today/week/month aufsteigend; sonst absteigend (jüngste zuerst)
  const ascending = ['upcoming', 'today', 'week', 'month'].includes(rangeFilter);
  filtered.sort((a, b) => {
    if (a.datum !== b.datum) return ascending
      ? a.datum.localeCompare(b.datum)
      : b.datum.localeCompare(a.datum);
    return ascending
      ? (a.uhrzeit_von || '').localeCompare(b.uhrzeit_von || '')
      : (b.uhrzeit_von || '').localeCompare(a.uhrzeit_von || '');
  });

  renderAppointmentsTable(filtered);
}

function renderAppointmentsTable(appointments) {
  const tbody = document.getElementById('appointments-table-body');
  const countEl = document.getElementById('appointments-count');

  const total = appointmentsCache.length;
  const shown = appointments.length;
  countEl.textContent = (shown === total)
    ? `${total} Termin${total === 1 ? '' : 'e'}`
    : `${shown} von ${total} Terminen`;

  if (shown === 0) {
    const msg = total === 0
      ? 'Noch keine Termine angelegt. Klicke oben auf „+ Neuer Termin".'
      : 'Keine Termine entsprechen den Filterkriterien.';
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty">${msg}</div></td></tr>`;
    return;
  }

  const todayISO = toISODate(new Date());

  tbody.innerHTML = appointments.map(a => {
    const typFarbe = a.typ?.farbe || '#6b7280';
    const typWert  = a.typ?.wert || '—';
    const isPast = a.datum < todayISO;

    const uhrzeit = a.uhrzeit_von
      ? (a.uhrzeit_bis ? `${formatTime(a.uhrzeit_von)}–${formatTime(a.uhrzeit_bis)}` : formatTime(a.uhrzeit_von))
      : '';

    const firmaHtml = a.company_id && a.company
      ? `<div class="cell-link" onclick="navigateTo('firma', '${esc(a.company_id)}')">${esc(a.company.name)}</div>`
      : '<span style="color:var(--muted);font-style:italic">—</span>';

    return `
      <tr>
        <td>
          <div class="date-cell${isPast ? ' past' : ''}">${esc(formatDateDE(a.datum))}</div>
        </td>
        <td class="col-tablet" style="color:var(--muted)">${esc(uhrzeit || '—')}</td>
        <td>
          <div class="cell-link" onclick="openAppointmentModal('edit', '${esc(a.id)}')">${esc(a.titel || '—')}</div>
        </td>
        <td class="col-tablet">
          <span class="badge" style="background:${esc(typFarbe)}22;color:${esc(typFarbe)}">${esc(typWert)}</span>
        </td>
        <td class="col-desktop">${firmaHtml}</td>
        <td class="col-desktop" style="color:var(--muted)">${esc(a.ort || '—')}</td>
        <td>
          <span class="badge" style="background:${appointmentStatusBg(a.status)};color:${appointmentStatusColor(a.status)}">${esc(appointmentStatusLabel(a.status))}</span>
        </td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="openAppointmentModal('edit', '${esc(a.id)}')">Bearbeiten</button>
        </td>
      </tr>`;
  }).join('');
}

async function openAppointmentModal(mode, appointmentId = null) {
  editingAppointmentId = appointmentId;
  lastAutoFilledOrt = '';

  // Firmen laden
  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name, strasse, plz, stadt').order('name');
    companiesCache = cs || [];
  } else {
    const { data: cs } = await db.from('companies').select('id, name, strasse, plz, stadt').order('name');
    companiesCache = cs || companiesCache;
  }

  const companySelect = document.getElementById('t-company');
  companySelect.innerHTML = '<option value="">— Keine Firma —</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');

  // Termintypen laden
  const typen = await loadTerminTypen();
  const typSelect = document.getElementById('t-typ');
  if (typen.length === 0) {
    typSelect.innerHTML = '<option value="">Keine Typen – bitte erst unter „Stammdaten" anlegen</option>';
  } else {
    typSelect.innerHTML = typen.map(t => `<option value="${esc(t.id)}">${esc(t.wert)}</option>`).join('');
  }

  document.getElementById('t-titel').value = '';
  document.getElementById('t-datum').value = toISODate(new Date());
  document.getElementById('t-uhrzeit-von').value = '';
  document.getElementById('t-uhrzeit-bis').value = '';
  document.getElementById('t-status').value = 'geplant';
  document.getElementById('t-ort').value = '';
  document.getElementById('t-notizen').value = '';
  document.getElementById('t-ort-hint').style.display = 'none';
  companySelect.value = '';

  await rebuildContactDropdownForAppointment('');
  await rebuildProjectDropdownForAppointment('');

  if (mode === 'new') {
    document.getElementById('modal-appointment-title').textContent = 'Neuer Termin';
    document.getElementById('t-save-btn').textContent = 'Anlegen';
    document.getElementById('t-delete-btn').style.display = 'none';

    // Prefill-Company aus Firmen-Detailseite
    if (appointmentModalPrefillCompanyId) {
      companySelect.value = appointmentModalPrefillCompanyId;
      await rebuildContactDropdownForAppointment(appointmentModalPrefillCompanyId);
      await rebuildProjectDropdownForAppointment(appointmentModalPrefillCompanyId);
      updateOrtHint();
      appointmentModalPrefillCompanyId = null;
    }

    // Prefill-Project aus Projekt-Detailseite
    if (appointmentModalPrefillProjectId) {
      // Projekt laden, um zugehörige Firma zu setzen
      const { data: proj } = await db.from('projects')
        .select('id, name, company_id').eq('id', appointmentModalPrefillProjectId).single();
      if (proj) {
        if (proj.company_id) {
          companySelect.value = proj.company_id;
          await rebuildContactDropdownForAppointment(proj.company_id);
          await rebuildProjectDropdownForAppointment(proj.company_id);
          updateOrtHint();
        } else {
          await rebuildProjectDropdownForAppointment('');
        }
        const projSelect = document.getElementById('t-project');
        if (projSelect) projSelect.value = proj.id;
      }
      appointmentModalPrefillProjectId = null;
    }

    // Prefill-Contact aus Kontakt-Detailseite
    if (appointmentModalPrefillContactId) {
      const { data: k } = await db.from('contacts')
        .select('id, vorname, nachname, company_id').eq('id', appointmentModalPrefillContactId).single();
      if (k) {
        if (k.company_id) {
          companySelect.value = k.company_id;
          await rebuildContactDropdownForAppointment(k.company_id);
          await rebuildProjectDropdownForAppointment(k.company_id);
          updateOrtHint();
        }
        document.getElementById('t-contact').value = k.id;
      }
      appointmentModalPrefillContactId = null;
    }
  } else {
    document.getElementById('modal-appointment-title').textContent = 'Termin bearbeiten';
    document.getElementById('t-save-btn').textContent = 'Speichern';
    document.getElementById('t-delete-btn').style.display = 'block';

    const { data, error } = await db.from('appointments').select('*').eq('id', appointmentId).single();
    if (error || !data) { showToast('Termin konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingAppointmentId = null; return; }

    document.getElementById('t-titel').value = data.titel || '';
    document.getElementById('t-datum').value = data.datum || '';
    document.getElementById('t-uhrzeit-von').value = data.uhrzeit_von ? data.uhrzeit_von.substring(0, 5) : '';
    document.getElementById('t-uhrzeit-bis').value = data.uhrzeit_bis ? data.uhrzeit_bis.substring(0, 5) : '';
    document.getElementById('t-status').value = data.status || 'geplant';
    document.getElementById('t-ort').value = data.ort || '';
    document.getElementById('t-notizen').value = data.notizen || '';
    if (data.typ_id) typSelect.value = data.typ_id;
    if (data.company_id) {
      companySelect.value = data.company_id;
      await rebuildContactDropdownForAppointment(data.company_id);
      await rebuildProjectDropdownForAppointment(data.company_id);
      if (data.contact_id) document.getElementById('t-contact').value = data.contact_id;
      updateOrtHint();
    } else {
      await rebuildProjectDropdownForAppointment('');
    }
    if (data.project_id) {
      const projSelect = document.getElementById('t-project');
      if (projSelect) projSelect.value = data.project_id;
    }
  }

  setupAppointmentAutoFill();

  document.getElementById('modal-appointment').classList.add('open');
  setTimeout(() => document.getElementById('t-titel').focus(), 100);
}

function closeAppointmentModal() {
  document.getElementById('modal-appointment').classList.remove('open');
  editingAppointmentId = null;
  appointmentModalPrefillCompanyId = null;
  appointmentModalPrefillProjectId = null;
  appointmentModalPrefillContactId = null;
  lastAutoFilledOrt = '';
}

async function rebuildContactDropdownForAppointment(companyId) {
  const contactSelect = document.getElementById('t-contact');
  if (!companyId) {
    contactSelect.innerHTML = '<option value="">— Erst Firma wählen —</option>';
    contactSelect.disabled = true;
    return;
  }
  contactSelect.disabled = false;
  const { data, error } = await db.from('contacts')
    .select('id, vorname, nachname').eq('company_id', companyId).order('nachname').order('vorname');
  if (error) { contactSelect.innerHTML = '<option value="">Fehler beim Laden</option>'; return; }

  const contacts = data || [];
  if (contacts.length === 0) {
    contactSelect.innerHTML = '<option value="">— Keine Kontakte bei dieser Firma —</option>';
  } else {
    contactSelect.innerHTML = '<option value="">— Kein Kontakt —</option>'
      + contacts.map(k => `<option value="${esc(k.id)}">${esc([k.vorname, k.nachname].filter(Boolean).join(' '))}</option>`).join('');
  }
}

function updateOrtHint() {
  const companyId = document.getElementById('t-company').value;
  const hint = document.getElementById('t-ort-hint');
  if (!companyId) { hint.style.display = 'none'; return; }
  const company = companiesCache.find(c => c.id === companyId);
  if (!company) { hint.style.display = 'none'; return; }
  const parts = [company.strasse, [company.plz, company.stadt].filter(Boolean).join(' ')].filter(Boolean);
  if (parts.length === 0) { hint.style.display = 'none'; return; }
  hint.innerHTML = `Firmenadresse: ${esc(parts.join(', '))} <span style="text-decoration:underline">· übernehmen</span>`;
  hint.style.display = '';
}

function useCompanyAddressForOrt() {
  const companyId = document.getElementById('t-company').value;
  if (!companyId) return;
  const company = companiesCache.find(c => c.id === companyId);
  if (!company) return;
  const parts = [company.strasse, [company.plz, company.stadt].filter(Boolean).join(' ')].filter(Boolean);
  if (parts.length === 0) return;
  const address = parts.join(', ');
  document.getElementById('t-ort').value = address;
  lastAutoFilledOrt = address;
}

function autoFillOrtIfAppropriate() {
  const typSelect = document.getElementById('t-typ');
  const typOption = typSelect.options[typSelect.selectedIndex];
  if (!typOption) return;
  const typName = (typOption.textContent || '').toLowerCase();
  if (!typName.includes('vor ort')) return;

  const ortInput = document.getElementById('t-ort');
  // Nur auto-fillen, wenn Feld leer ist oder noch den letzten Auto-Fill enthält
  if (ortInput.value !== '' && ortInput.value !== lastAutoFilledOrt) return;

  const companyId = document.getElementById('t-company').value;
  if (!companyId) return;
  const company = companiesCache.find(c => c.id === companyId);
  if (!company) return;
  const parts = [company.strasse, [company.plz, company.stadt].filter(Boolean).join(' ')].filter(Boolean);
  if (parts.length === 0) return;
  const address = parts.join(', ');
  ortInput.value = address;
  lastAutoFilledOrt = address;
}

function setupAppointmentAutoFill() {
  const companySelect = document.getElementById('t-company');
  const typSelect = document.getElementById('t-typ');

  companySelect.onchange = async () => {
    await rebuildContactDropdownForAppointment(companySelect.value);
    await rebuildProjectDropdownForAppointment(companySelect.value);
    updateOrtHint();
    autoFillOrtIfAppropriate();
  };

  typSelect.onchange = () => {
    autoFillOrtIfAppropriate();
  };
}

async function saveAppointment() {
  const titel        = document.getElementById('t-titel').value.trim();
  const datum        = document.getElementById('t-datum').value;
  const uhrzeit_von  = document.getElementById('t-uhrzeit-von').value;
  const uhrzeit_bis  = document.getElementById('t-uhrzeit-bis').value;
  const typ_id       = document.getElementById('t-typ').value;
  const status       = document.getElementById('t-status').value;
  const company_id   = document.getElementById('t-company').value || null;
  const contact_id   = document.getElementById('t-contact').value || null;
  const project_id   = document.getElementById('t-project')?.value || null;
  const ort          = document.getElementById('t-ort').value.trim();
  const notizen      = document.getElementById('t-notizen').value.trim();
  const btn          = document.getElementById('t-save-btn');

  if (!titel)   { showToast('Bitte Titel eingeben.', true); return; }
  if (!datum)   { showToast('Bitte Datum wählen.', true); return; }
  if (!typ_id)  { showToast('Bitte Typ auswählen.', true); return; }
  if (!['geplant', 'durchgefuehrt'].includes(status)) { showToast('Status ungültig.', true); return; }

  if (uhrzeit_von && uhrzeit_bis && uhrzeit_von >= uhrzeit_bis) {
    showToast('„Uhrzeit bis" muss nach „Uhrzeit von" liegen.', true);
    return;
  }

  btn.disabled = true;
  btn.textContent = editingAppointmentId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const payload = {
      titel, datum,
      uhrzeit_von: uhrzeit_von || null,
      uhrzeit_bis: uhrzeit_bis || null,
      typ_id, status,
      company_id, contact_id, project_id,
      ort: ort || null,
      notizen: notizen || null
    };
    if (!editingAppointmentId) payload.erstellt_von = currentUser?.id || null;

    let error;
    if (editingAppointmentId) { ({ error } = await db.from('appointments').update(payload).eq('id', editingAppointmentId)); }
    else { ({ error } = await db.from('appointments').insert(payload)); }
    if (error) throw new Error(error.message);

    closeAppointmentModal();
    showToast(editingAppointmentId ? 'Termin aktualisiert.' : 'Termin angelegt.');

    // Kontext-sensibles Refresh
    if (currentContactDetailId && document.getElementById('page-contact-detail').classList.contains('active')) {
      await loadContactAppointments(currentContactDetailId);
    } else if (currentProjectDetailId && document.getElementById('page-project-detail').classList.contains('active')) {
      await loadProjectAppointments(currentProjectDetailId);
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await Promise.all([
        loadCompanyAppointments(currentCompanyDetailId),
        loadCompanyAppointmentMap()
      ]);
    } else {
      await loadAppointments();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingAppointmentId ? 'Speichern' : 'Anlegen';
  }
}

async function deleteAppointment() {
  if (!editingAppointmentId) return;
  if (!confirm('Termin wirklich löschen?')) return;

  const btn = document.getElementById('t-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const { error } = await db.from('appointments').delete().eq('id', editingAppointmentId);
    if (error) throw new Error(error.message);

    closeAppointmentModal();
    showToast('Termin gelöscht.');

    if (currentContactDetailId && document.getElementById('page-contact-detail').classList.contains('active')) {
      await loadContactAppointments(currentContactDetailId);
    } else if (currentProjectDetailId && document.getElementById('page-project-detail').classList.contains('active')) {
      await loadProjectAppointments(currentProjectDetailId);
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await Promise.all([
        loadCompanyAppointments(currentCompanyDetailId),
        loadCompanyAppointmentMap()
      ]);
    } else {
      await loadAppointments();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

// ═══════════════════════════════════════════════════════════
//  PROJEKTE (PROJECTS)
// ═══════════════════════════════════════════════════════════

async function loadProjektStatus() {
  if (projektStatusCache.length > 0) return projektStatusCache;
  const { data, error } = await db.from('lookup_values')
    .select('id, wert, farbe, reihenfolge').eq('kategorie', 'projekt_status').eq('ist_aktiv', true).order('reihenfolge');
  if (error) { showToast('Fehler beim Laden der Projekt-Status: ' + error.message, true); return []; }
  projektStatusCache = data || [];
  return projektStatusCache;
}

function projektStatusFarbe(wert) {
  const s = projektStatusCache.find(x => x.wert === wert);
  return s?.farbe || '#6b7280';
}

async function loadUserProfilesCache() {
  if (userProfilesCache.length > 0) return userProfilesCache;
  const { data, error } = await db.from('user_profiles')
    .select('id, name, email').in('status', ['aktiv', 'eingeladen']).order('name');
  if (error) { return []; }
  userProfilesCache = data || [];
  return userProfilesCache;
}

async function loadProjects() {
  const tbody = document.getElementById('projects-table-body');
  tbody.innerHTML = '<tr><td colspan="8"><div class="empty">Lade Projekte ...</div></td></tr>';

  await loadProjektStatus();

  // Firmen sicherstellen
  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name').order('name');
    companiesCache = cs || [];
  }

  // User sicherstellen
  await loadUserProfilesCache();

  // Filter-Dropdowns befüllen
  const statusFilter = document.getElementById('projects-status-filter');
  if (statusFilter.options.length <= 2) {
    const existing = statusFilter.value;
    let options = '<option value="">Alle Status</option><option value="_active">Aktive (Lead, Angebot, In Arbeit)</option>';
    options += projektStatusCache.map(s => `<option value="${esc(s.wert)}">${esc(s.wert)}</option>`).join('');
    statusFilter.innerHTML = options;
    if (existing) statusFilter.value = existing;
  }

  const companyFilter = document.getElementById('projects-company-filter');
  const existingComp = companyFilter.value;
  companyFilter.innerHTML = '<option value="">Alle Firmen</option><option value="__none__">Interne Projekte (ohne Firma)</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  if (existingComp) companyFilter.value = existingComp;

  const userFilter = document.getElementById('projects-verantwortlicher-filter');
  const existingUser = userFilter.value;
  userFilter.innerHTML = '<option value="">Alle Verantwortlichen</option>'
    + '<option value="__none__">Ohne Verantwortlichen</option>'
    + userProfilesCache.map(u => `<option value="${esc(u.id)}">${esc(u.name)}</option>`).join('');
  if (existingUser) userFilter.value = existingUser;

  const { data, error } = await db.from('projects')
    .select('*, company:companies(id, name), verantwortlicher:user_profiles!projects_verantwortlicher_id_fkey(id, name)')
    .order('startdatum', { ascending: false, nullsFirst: false });

  if (error) { tbody.innerHTML = `<tr><td colspan="8"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`; return; }

  projectsCache = data || [];
  filterProjects();
}

function filterProjects() {
  const searchTerm       = document.getElementById('projects-search').value.trim().toLowerCase();
  const statusFilterVal  = document.getElementById('projects-status-filter').value;
  const companyFilterVal = document.getElementById('projects-company-filter').value;
  const userFilterVal    = document.getElementById('projects-verantwortlicher-filter').value;

  let filtered = projectsCache;

  if (statusFilterVal === '_active') {
    filtered = filtered.filter(p => ['Lead', 'Angebot', 'In Arbeit'].includes(p.status));
  } else if (statusFilterVal) {
    filtered = filtered.filter(p => p.status === statusFilterVal);
  }

  if (companyFilterVal === '__none__') {
    filtered = filtered.filter(p => !p.company_id);
  } else if (companyFilterVal) {
    filtered = filtered.filter(p => p.company_id === companyFilterVal);
  }

  if (userFilterVal === '__none__') {
    filtered = filtered.filter(p => !p.verantwortlicher_id);
  } else if (userFilterVal) {
    filtered = filtered.filter(p => p.verantwortlicher_id === userFilterVal);
  }

  if (searchTerm) {
    filtered = filtered.filter(p => {
      const haystack = [p.name, p.beschreibung, p.notizen, p.company?.name, p.verantwortlicher?.name]
        .filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(searchTerm);
    });
  }

  renderProjectsTable(filtered);
}

function renderProjectsTable(projects) {
  const tbody = document.getElementById('projects-table-body');
  const countEl = document.getElementById('projects-count');

  const total = projectsCache.length;
  const shown = projects.length;
  countEl.textContent = (shown === total)
    ? `${total} Projekt${total === 1 ? '' : 'e'}`
    : `${shown} von ${total} Projekten`;

  if (shown === 0) {
    const msg = total === 0
      ? 'Noch keine Projekte angelegt. Klicke oben auf „+ Neues Projekt".'
      : 'Keine Projekte entsprechen den Filterkriterien.';
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty">${msg}</div></td></tr>`;
    return;
  }

  tbody.innerHTML = projects.map(p => {
    const statusColor = projektStatusFarbe(p.status);
    const firmaHtml = p.company_id && p.company
      ? `<div class="cell-link" onclick="navigateTo('firma', '${esc(p.company_id)}')">${esc(p.company.name)}</div>`
      : '<span style="color:var(--muted);font-style:italic">Intern</span>';
    const verantwortlich = p.verantwortlicher?.name
      ? esc(p.verantwortlicher.name)
      : '<span style="color:var(--muted);font-style:italic">—</span>';

    return `
      <tr>
        <td>
          <div class="cell-link" onclick="navigateTo('projekt', '${esc(p.id)}')">${esc(p.name)}</div>
          ${p.beschreibung ? `<div style="font-size:11px;color:var(--muted);margin-top:2px;max-width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(p.beschreibung)}</div>` : ''}
        </td>
        <td><span class="badge" style="background:${esc(statusColor)}22;color:${esc(statusColor)}">${esc(p.status)}</span></td>
        <td class="col-tablet">${firmaHtml}</td>
        <td class="col-desktop" style="color:var(--muted)">${verantwortlich}</td>
        <td class="col-desktop" style="color:var(--muted)">${p.startdatum ? esc(formatDateCompact(p.startdatum)) : '—'}</td>
        <td class="col-desktop" style="color:var(--muted)">${p.enddatum ? esc(formatDateCompact(p.enddatum)) : '—'}</td>
        <td class="col-tablet">${esc(formatPreis(p.geschaetzter_umsatz))}</td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="navigateTo('projekt', '${esc(p.id)}')">Details</button>
        </td>
      </tr>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════════
//  PROJEKT-MODAL
// ═══════════════════════════════════════════════════════════

async function openProjectModal(mode, projectId = null) {
  editingProjectId = projectId;

  await loadProjektStatus();

  // Firmen laden
  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name').order('name');
    companiesCache = cs || [];
  }

  await loadUserProfilesCache();

  const statusSelect = document.getElementById('p-status');
  statusSelect.innerHTML = projektStatusCache.map(s =>
    `<option value="${esc(s.wert)}">${esc(s.wert)}</option>`).join('');

  const companySelect = document.getElementById('p-company');
  companySelect.innerHTML = '<option value="">— Intern (ohne Firma) —</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');

  const userSelect = document.getElementById('p-verantwortlicher');
  userSelect.innerHTML = '<option value="">— Kein Verantwortlicher —</option>'
    + userProfilesCache.map(u => `<option value="${esc(u.id)}">${esc(u.name)}</option>`).join('');

  const hauptkontaktSelect = document.getElementById('p-hauptkontakt');
  hauptkontaktSelect.innerHTML = '<option value="">— Erst Firma wählen —</option>';
  hauptkontaktSelect.disabled = true;

  // Firma onchange → Hauptkontakt-Dropdown neu aufbauen
  companySelect.onchange = async () => {
    await rebuildHauptkontaktDropdown(companySelect.value);
  };

  document.getElementById('p-name').value = '';
  document.getElementById('p-beschreibung').value = '';
  document.getElementById('p-startdatum').value = '';
  document.getElementById('p-enddatum').value = '';
  document.getElementById('p-umsatz').value = '';
  document.getElementById('p-notizen').value = '';
  statusSelect.value = 'Angebot';
  companySelect.value = '';

  if (mode === 'new') {
    document.getElementById('modal-project-title').textContent = 'Neues Projekt';
    document.getElementById('p-save-btn').textContent = 'Anlegen';
    document.getElementById('p-delete-btn').style.display = 'none';

    // Verantwortlicher: Default = aktueller User
    if (currentUser?.id) userSelect.value = currentUser.id;

    // Prefill-Company aus Firmen-Detailseite
    if (projectModalPrefillCompanyId) {
      companySelect.value = projectModalPrefillCompanyId;
      await rebuildHauptkontaktDropdown(projectModalPrefillCompanyId);
      projectModalPrefillCompanyId = null;
    }

    // Prefill-Hauptkontakt aus Kontakt-Detailseite (setzt auch Firma vor)
    if (projectModalPrefillHauptkontaktId) {
      const { data: k } = await db.from('contacts')
        .select('id, company_id').eq('id', projectModalPrefillHauptkontaktId).single();
      if (k) {
        if (k.company_id) {
          companySelect.value = k.company_id;
          await rebuildHauptkontaktDropdown(k.company_id);
        }
        hauptkontaktSelect.value = k.id;
      }
      projectModalPrefillHauptkontaktId = null;
    }
  } else {
    document.getElementById('modal-project-title').textContent = 'Projekt bearbeiten';
    document.getElementById('p-save-btn').textContent = 'Speichern';
    document.getElementById('p-delete-btn').style.display = 'block';

    const { data, error } = await db.from('projects').select('*').eq('id', projectId).single();
    if (error || !data) { showToast('Projekt konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingProjectId = null; return; }

    document.getElementById('p-name').value = data.name || '';
    document.getElementById('p-beschreibung').value = data.beschreibung || '';
    document.getElementById('p-startdatum').value = data.startdatum || '';
    document.getElementById('p-enddatum').value = data.enddatum || '';
    document.getElementById('p-umsatz').value = data.geschaetzter_umsatz ?? '';
    document.getElementById('p-notizen').value = data.notizen || '';
    statusSelect.value = data.status || 'Angebot';
    if (data.verantwortlicher_id) userSelect.value = data.verantwortlicher_id;
    if (data.company_id) {
      companySelect.value = data.company_id;
      await rebuildHauptkontaktDropdown(data.company_id);
      if (data.hauptkontakt_id) hauptkontaktSelect.value = data.hauptkontakt_id;
    }
  }

  document.getElementById('modal-project').classList.add('open');
  setTimeout(() => document.getElementById('p-name').focus(), 100);
}

async function rebuildHauptkontaktDropdown(companyId) {
  const hauptkontaktSelect = document.getElementById('p-hauptkontakt');
  if (!companyId) {
    hauptkontaktSelect.innerHTML = '<option value="">— Erst Firma wählen —</option>';
    hauptkontaktSelect.disabled = true;
    return;
  }
  hauptkontaktSelect.disabled = false;
  const { data, error } = await db.from('contacts')
    .select('id, vorname, nachname').eq('company_id', companyId).order('nachname').order('vorname');
  if (error) { hauptkontaktSelect.innerHTML = '<option value="">Fehler beim Laden</option>'; return; }
  const contacts = data || [];
  if (contacts.length === 0) {
    hauptkontaktSelect.innerHTML = '<option value="">— Keine Kontakte bei dieser Firma —</option>';
  } else {
    hauptkontaktSelect.innerHTML = '<option value="">— Kein Hauptkontakt —</option>'
      + contacts.map(k => `<option value="${esc(k.id)}">${esc([k.vorname, k.nachname].filter(Boolean).join(' '))}</option>`).join('');
  }
}

function closeProjectModal() {
  document.getElementById('modal-project').classList.remove('open');
  editingProjectId = null;
  projectModalPrefillCompanyId = null;
  projectModalPrefillHauptkontaktId = null;
}

async function saveProject() {
  const name              = document.getElementById('p-name').value.trim();
  const status            = document.getElementById('p-status').value;
  const company_id        = document.getElementById('p-company').value || null;
  const hauptkontakt_id   = document.getElementById('p-hauptkontakt').value || null;
  const verantwortlicher_id = document.getElementById('p-verantwortlicher').value || null;
  const startdatum        = document.getElementById('p-startdatum').value || null;
  const enddatum          = document.getElementById('p-enddatum').value || null;
  const umsatzRaw         = document.getElementById('p-umsatz').value;
  const beschreibung      = document.getElementById('p-beschreibung').value.trim();
  const notizen           = document.getElementById('p-notizen').value.trim();
  const btn               = document.getElementById('p-save-btn');

  if (!name) { showToast('Bitte Name eingeben.', true); return; }
  if (!status) { showToast('Bitte Status auswählen.', true); return; }
  if (!['Lead', 'Angebot', 'In Arbeit', 'Abgeschlossen', 'Verloren'].includes(status)) {
    showToast('Status ungültig.', true); return;
  }
  if (startdatum && enddatum && startdatum > enddatum) {
    showToast('Enddatum muss nach Startdatum liegen.', true); return;
  }
  if (hauptkontakt_id && !company_id) {
    showToast('Hauptkontakt ohne Firma ist nicht möglich.', true); return;
  }

  const geschaetzter_umsatz = umsatzRaw === '' ? 0 : Number(umsatzRaw);
  if (Number.isNaN(geschaetzter_umsatz) || geschaetzter_umsatz < 0) {
    showToast('Umsatz muss eine Zahl ≥ 0 sein.', true); return;
  }

  btn.disabled = true;
  btn.textContent = editingProjectId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const payload = {
      name, status,
      company_id, hauptkontakt_id, verantwortlicher_id,
      startdatum, enddatum,
      geschaetzter_umsatz,
      beschreibung: beschreibung || null,
      notizen: notizen || null
    };
    if (!editingProjectId) payload.erstellt_von = currentUser?.id || null;

    const savedId = editingProjectId;

    let error;
    if (editingProjectId) { ({ error } = await db.from('projects').update(payload).eq('id', editingProjectId)); }
    else { ({ error } = await db.from('projects').insert(payload)); }
    if (error) throw new Error(error.message);

    closeProjectModal();
    showToast(savedId ? 'Projekt aktualisiert.' : 'Projekt angelegt.');

    // Kontext-sensibles Refresh
    if (savedId && currentProjectDetailId === savedId) {
      await loadProjectDetail(savedId);
    } else if (currentContactDetailId && document.getElementById('page-contact-detail').classList.contains('active')) {
      await loadContactProjects(currentContactDetailId);
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await loadCompanyProjects(currentCompanyDetailId);
    } else {
      await loadProjects();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingProjectId ? 'Speichern' : 'Anlegen';
  }
}

async function deleteProject() {
  if (!editingProjectId) return;
  if (!confirm('Projekt wirklich löschen?\n\nHinweis: Zugeordnete Termine verlieren die Projekt-Zuordnung, werden aber nicht gelöscht.')) return;

  const btn = document.getElementById('p-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const deletedId = editingProjectId;
    const { error } = await db.from('projects').delete().eq('id', deletedId);
    if (error) {
      if (error.message.toLowerCase().includes('foreign key') || error.code === '23503') {
        throw new Error('Dieses Projekt hat noch verknüpfte Einträge. Diese müssen zuerst entfernt werden.');
      }
      throw new Error(error.message);
    }
    closeProjectModal();
    showToast('Projekt gelöscht.');

    if (currentProjectDetailId === deletedId) {
      currentProjectDetailId = null;
      navigateTo('projects');
    } else if (currentContactDetailId && document.getElementById('page-contact-detail').classList.contains('active')) {
      await loadContactProjects(currentContactDetailId);
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await loadCompanyProjects(currentCompanyDetailId);
    } else {
      await loadProjects();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

// ═══════════════════════════════════════════════════════════
//  PROJEKT-DETAILSEITE
// ═══════════════════════════════════════════════════════════

async function loadProjectDetail(projectId) {
  currentProjectDetailId = projectId;

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-project-detail').classList.add('active');
  document.querySelectorAll('.nav-item:not(.nav-item-group)').forEach(b => b.classList.remove('active'));
  document.getElementById('nav-projects')?.classList.add('active');
  setMobileNav('project-detail');

  document.getElementById('project-detail-name').textContent = '…';
  document.getElementById('project-detail-title').textContent = '…';
  document.getElementById('project-detail-subline').innerHTML = '';
  document.getElementById('project-detail-info').innerHTML = '<div style="color:var(--muted);font-size:13px">Lade Projekt ...</div>';
  document.getElementById('project-detail-beschreibung-wrap').style.display = 'none';
  document.getElementById('project-detail-notizen-wrap').style.display = 'none';
  document.getElementById('project-appointments-body').innerHTML = '<tr><td colspan="6"><div class="empty">Lade Termine ...</div></td></tr>';

  await loadProjektStatus();

  const { data, error } = await db.from('projects')
    .select('*, company:companies(id, name), hauptkontakt:contacts(id, vorname, nachname, email, telefon), verantwortlicher:user_profiles!projects_verantwortlicher_id_fkey(id, name, email)')
    .eq('id', projectId).single();

  if (error || !data) {
    document.getElementById('project-detail-info').innerHTML = `<div style="color:var(--danger);font-size:13px">Projekt nicht gefunden oder Fehler: ${esc(error?.message || 'Unbekannt')}</div>`;
    document.getElementById('project-detail-title').textContent = 'Fehler';
    document.getElementById('project-detail-name').textContent = 'Fehler';
    return;
  }

  renderProjectDetail(data);
  await loadProjectAppointments(projectId);
}

function renderProjectDetail(p) {
  document.getElementById('project-detail-name').textContent = p.name;
  document.getElementById('project-detail-title').textContent = p.name;

  const statusColor = projektStatusFarbe(p.status);
  const subline = document.getElementById('project-detail-subline');
  const sublineParts = [`<span class="badge" style="background:${esc(statusColor)}22;color:${esc(statusColor)}">${esc(p.status)}</span>`];
  if (p.company) {
    sublineParts.push(`<span>· <span class="cell-link" onclick="navigateTo('firma', '${esc(p.company.id)}')">${esc(p.company.name)}</span></span>`);
  } else {
    sublineParts.push('<span>· Internes Projekt</span>');
  }
  subline.innerHTML = sublineParts.join('');

  const editBtn = document.getElementById('project-detail-edit-btn');
  editBtn.onclick = () => openProjectModal('edit', p.id);

  document.getElementById('project-detail-add-appointment-btn').onclick = () => {
    appointmentModalPrefillProjectId = p.id;
    openAppointmentModal('new');
  };

  document.getElementById('project-detail-add-deployment-btn').onclick = () => {
    deploymentModalPrefillProjectId = p.id;
    deploymentModalPrefillCompanyId = p.company?.id || null;
    openDeploymentModal('new');
  };

  const hauptkontaktName = p.hauptkontakt
    ? [p.hauptkontakt.vorname, p.hauptkontakt.nachname].filter(Boolean).join(' ')
    : null;

  const verantwortlicherName = p.verantwortlicher?.name || null;

  const info = document.getElementById('project-detail-info');
  info.innerHTML = `
    <div class="detail-field">
      <div class="detail-label">Verantwortlich</div>
      <div class="detail-value">${verantwortlicherName ? esc(verantwortlicherName) : '<span class="detail-value-muted">—</span>'}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Hauptkontakt</div>
      <div class="detail-value">${hauptkontaktName ? esc(hauptkontaktName) : '<span class="detail-value-muted">—</span>'}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Startdatum</div>
      <div class="detail-value">${p.startdatum ? esc(formatDateDE(p.startdatum)) : '<span class="detail-value-muted">—</span>'}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Enddatum (geplant)</div>
      <div class="detail-value">${p.enddatum ? esc(formatDateDE(p.enddatum)) : '<span class="detail-value-muted">—</span>'}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Geschätzter Umsatz</div>
      <div class="detail-value" style="font-weight:500">${esc(formatPreis(p.geschaetzter_umsatz))}</div>
    </div>
  `;

  if (p.beschreibung) {
    document.getElementById('project-detail-beschreibung-wrap').style.display = '';
    document.getElementById('project-detail-beschreibung').textContent = p.beschreibung;
  } else {
    document.getElementById('project-detail-beschreibung-wrap').style.display = 'none';
  }

  if (p.notizen) {
    document.getElementById('project-detail-notizen-wrap').style.display = '';
    document.getElementById('project-detail-notizen').textContent = p.notizen;
  } else {
    document.getElementById('project-detail-notizen-wrap').style.display = 'none';
  }
}

async function loadProjectAppointments(projectId) {
  const tbody = document.getElementById('project-appointments-body');
  const countEl = document.getElementById('project-appointments-count');

  const { data, error } = await db.from('appointments')
    .select('*, typ:lookup_values!appointments_typ_id_fkey(id, wert, farbe)')
    .eq('project_id', projectId);

  if (error) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Termine';
    return;
  }

  const all = data || [];
  const total = all.length;

  if (total === 0) {
    countEl.textContent = 'Keine Termine';
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Noch keine Termine für dieses Projekt. Klicke oben auf „+ Termin hinzufügen".</div></td></tr>';
    return;
  }

  const anzGeplant       = all.filter(a => a.status === 'geplant').length;
  const anzDurchgefuehrt = all.filter(a => a.status === 'durchgefuehrt').length;
  countEl.textContent = `${total} Termin${total === 1 ? '' : 'e'} · ${anzGeplant} geplant · ${anzDurchgefuehrt} durchgeführt`;

  const todayISO = toISODate(new Date());
  const upcoming = all.filter(a => a.datum >= todayISO)
    .sort((a, b) => a.datum === b.datum
      ? (a.uhrzeit_von || '').localeCompare(b.uhrzeit_von || '')
      : a.datum.localeCompare(b.datum));
  const past = all.filter(a => a.datum < todayISO)
    .sort((a, b) => a.datum === b.datum
      ? (b.uhrzeit_von || '').localeCompare(a.uhrzeit_von || '')
      : b.datum.localeCompare(a.datum));

  const sorted = upcoming.concat(past);

  tbody.innerHTML = sorted.map(a => {
    const typFarbe = a.typ?.farbe || '#6b7280';
    const typWert  = a.typ?.wert || '—';
    const isPast = a.datum < todayISO;
    const uhrzeit = a.uhrzeit_von
      ? (a.uhrzeit_bis ? `${formatTime(a.uhrzeit_von)}–${formatTime(a.uhrzeit_bis)}` : formatTime(a.uhrzeit_von))
      : '';

    return `
      <tr>
        <td><div class="date-cell${isPast ? ' past' : ''}">${esc(formatDateDE(a.datum))}</div></td>
        <td class="col-tablet" style="color:var(--muted)">${esc(uhrzeit || '—')}</td>
        <td>
          <div class="cell-link" onclick="openAppointmentModal('edit', '${esc(a.id)}')">${esc(a.titel || '—')}</div>
        </td>
        <td class="col-tablet">
          <span class="badge" style="background:${esc(typFarbe)}22;color:${esc(typFarbe)}">${esc(typWert)}</span>
        </td>
        <td>
          <span class="badge" style="background:${appointmentStatusBg(a.status)};color:${appointmentStatusColor(a.status)}">${esc(appointmentStatusLabel(a.status))}</span>
        </td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="openAppointmentModal('edit', '${esc(a.id)}')">Bearbeiten</button>
        </td>
      </tr>`;
  }).join('');

  // Show-All-Link immer ausblenden (wir zeigen hier ohnehin alle)
  document.getElementById('project-appointments-show-all').style.display = 'none';
}

// ═══════════════════════════════════════════════════════════
//  PROJEKTE AUF FIRMEN-DETAILSEITE
// ═══════════════════════════════════════════════════════════

async function loadCompanyProjects(companyId) {
  const tbody = document.getElementById('company-projects-body');
  const countEl = document.getElementById('company-projects-count');

  await loadProjektStatus();

  const { data, error } = await db.from('projects')
    .select('*').eq('company_id', companyId)
    .order('startdatum', { ascending: false, nullsFirst: false });

  if (error) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Projekte';
    return;
  }

  const all = data || [];
  const total = all.length;

  if (total === 0) {
    countEl.textContent = 'Keine Projekte';
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Noch keine Projekte für diese Firma. Klicke oben auf „+ Projekt hinzufügen".</div></td></tr>';
    return;
  }

  const anzAktiv = all.filter(p => ['Lead', 'Angebot', 'In Arbeit'].includes(p.status)).length;
  const anzAbgeschlossen = all.filter(p => p.status === 'Abgeschlossen').length;
  countEl.textContent = `${total} Projekt${total === 1 ? '' : 'e'} · ${anzAktiv} aktiv · ${anzAbgeschlossen} abgeschlossen`;

  // Sortierung: aktive zuerst, dann abgeschlossen, dann verloren
  const sortPrio = { 'In Arbeit': 1, 'Angebot': 2, 'Lead': 3, 'Abgeschlossen': 4, 'Verloren': 5 };
  const sorted = [...all].sort((a, b) => {
    const pa = sortPrio[a.status] || 99;
    const pb = sortPrio[b.status] || 99;
    if (pa !== pb) return pa - pb;
    return (b.startdatum || '').localeCompare(a.startdatum || '');
  });

  tbody.innerHTML = sorted.map(p => {
    const statusColor = projektStatusFarbe(p.status);
    return `
      <tr>
        <td>
          <div class="cell-link" onclick="navigateTo('projekt', '${esc(p.id)}')">${esc(p.name)}</div>
        </td>
        <td><span class="badge" style="background:${esc(statusColor)}22;color:${esc(statusColor)}">${esc(p.status)}</span></td>
        <td class="col-tablet" style="color:var(--muted)">${p.startdatum ? esc(formatDateCompact(p.startdatum)) : '—'}</td>
        <td class="col-tablet" style="color:var(--muted)">${p.enddatum ? esc(formatDateCompact(p.enddatum)) : '—'}</td>
        <td class="col-desktop">${esc(formatPreis(p.geschaetzter_umsatz))}</td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="navigateTo('projekt', '${esc(p.id)}')">Details</button>
        </td>
      </tr>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════════
//  PROJEKT-DROPDOWN IM TERMIN-MODAL
// ═══════════════════════════════════════════════════════════

async function rebuildProjectDropdownForAppointment(companyId) {
  const projectSelect = document.getElementById('t-project');
  if (!projectSelect) return;

  // Alle aktiven Projekte der Firma (oder interne, wenn keine Firma)
  let query = db.from('projects')
    .select('id, name, status')
    .in('status', ['Lead', 'Angebot', 'In Arbeit']);

  if (companyId) {
    query = query.eq('company_id', companyId);
  } else {
    query = query.is('company_id', null);
  }

  const { data, error } = await query.order('name');

  if (error) { projectSelect.innerHTML = '<option value="">Fehler beim Laden</option>'; return; }

  const projects = data || [];
  if (projects.length === 0) {
    const hint = companyId ? 'Keine aktiven Projekte bei dieser Firma' : 'Keine aktiven internen Projekte';
    projectSelect.innerHTML = `<option value="">— ${hint} —</option>`;
  } else {
    projectSelect.innerHTML = '<option value="">— Kein Projekt —</option>'
      + projects.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
  }
}

// ═══════════════════════════════════════════════════════════
//  KONTAKT-DETAILSEITE
// ═══════════════════════════════════════════════════════════

async function loadContactDetail(contactId) {
  currentContactDetailId = contactId;

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-contact-detail').classList.add('active');
  document.querySelectorAll('.nav-item:not(.nav-item-group)').forEach(b => b.classList.remove('active'));
  setMobileNav('contact-detail');

  document.getElementById('contact-detail-name').textContent = '…';
  document.getElementById('contact-detail-title').textContent = '…';
  document.getElementById('contact-detail-avatar').textContent = '…';
  document.getElementById('contact-detail-subline').innerHTML = '';
  document.getElementById('contact-detail-info').innerHTML = '<div style="color:var(--muted);font-size:13px">Lade Kontakt ...</div>';
  document.getElementById('contact-detail-notizen-wrap').style.display = 'none';
  document.getElementById('contact-appointments-body').innerHTML = '<tr><td colspan="6"><div class="empty">Lade Termine ...</div></td></tr>';
  document.getElementById('contact-projects-body').innerHTML = '<tr><td colspan="6"><div class="empty">Lade Projekte ...</div></td></tr>';

  const { data, error } = await db.from('contacts')
    .select('*, company:companies(id, name, strasse, plz, stadt)')
    .eq('id', contactId).single();

  if (error || !data) {
    document.getElementById('contact-detail-info').innerHTML = `<div style="color:var(--danger);font-size:13px">Kontakt nicht gefunden oder Fehler: ${esc(error?.message || 'Unbekannt')}</div>`;
    document.getElementById('contact-detail-title').textContent = 'Fehler';
    document.getElementById('contact-detail-name').textContent = 'Fehler';
    return;
  }

  // Cache aktualisieren, damit synchroner Copy direkt klappt
  if (data.company_id) {
    if (!companyContactsMap[data.company_id]) companyContactsMap[data.company_id] = [];
    const existing = companyContactsMap[data.company_id].findIndex(k => k.id === data.id);
    if (existing >= 0) companyContactsMap[data.company_id][existing] = data;
    else companyContactsMap[data.company_id].push(data);
  }

  renderContactDetail(data);
  await Promise.all([
    loadContactAppointments(contactId),
    loadContactProjects(contactId),
    loadProjektStatus()
  ]);
  // Projekte nochmal rendern, falls sie vor projektStatus fertig waren
  await loadContactProjects(contactId);
}

function renderContactDetail(k) {
  const fullName = [k.vorname, k.nachname].filter(Boolean).join(' ').trim() || '(Ohne Namen)';
  document.getElementById('contact-detail-name').textContent = fullName;
  document.getElementById('contact-detail-title').textContent = fullName;
  document.getElementById('contact-detail-avatar').textContent = ini(fullName);

  // Subline: Badge + Firma-Link oder "Ohne Firma"
  const subline = document.getElementById('contact-detail-subline');
  const sublineParts = ['<span class="badge" style="background:#eff6ff;color:#1d4ed8">Kontakt</span>'];
  if (k.position) sublineParts.push(`<span>· ${esc(k.position)}</span>`);
  if (k.company) {
    sublineParts.push(`<span>· <span class="cell-link" onclick="navigateTo('firma', '${esc(k.company.id)}')">${esc(k.company.name)}</span></span>`);
  } else {
    sublineParts.push('<span>· Ohne Firma</span>');
  }
  subline.innerHTML = sublineParts.join('');

  // Buttons verdrahten
  document.getElementById('contact-detail-edit-btn').onclick = () => openContactModal('edit', k.id);
  document.getElementById('contact-detail-copy-btn').onclick = () => copyContactById(k.id);

  document.getElementById('contact-detail-add-appointment-btn').onclick = () => {
    appointmentModalPrefillContactId = k.id;
    openAppointmentModal('new');
  };

  document.getElementById('contact-detail-add-project-btn').onclick = () => {
    projectModalPrefillHauptkontaktId = k.id;
    openProjectModal('new');
  };

  // Detail-Grid
  const telHtml = k.telefon
    ? `<a href="tel:${esc(k.telefon)}">${esc(k.telefon)}</a>`
    : '<span class="detail-value-muted">—</span>';
  const mailHtml = k.email
    ? `<a href="mailto:${esc(k.email)}">${esc(k.email)}</a>`
    : '<span class="detail-value-muted">—</span>';
  const positionHtml = k.position
    ? esc(k.position)
    : '<span class="detail-value-muted">—</span>';
  const firmaHtml = k.company
    ? `<span class="cell-link" onclick="navigateTo('firma', '${esc(k.company.id)}')">${esc(k.company.name)}</span>`
    : '<span class="detail-value-muted">Ohne Firma</span>';

  document.getElementById('contact-detail-info').innerHTML = `
    <div class="detail-field">
      <div class="detail-label">Telefon</div>
      <div class="detail-value">${telHtml}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">E-Mail</div>
      <div class="detail-value">${mailHtml}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Position</div>
      <div class="detail-value">${positionHtml}</div>
    </div>
    <div class="detail-field">
      <div class="detail-label">Firma</div>
      <div class="detail-value">${firmaHtml}</div>
    </div>
  `;

  if (k.notizen) {
    document.getElementById('contact-detail-notizen-wrap').style.display = '';
    document.getElementById('contact-detail-notizen').textContent = k.notizen;
  } else {
    document.getElementById('contact-detail-notizen-wrap').style.display = 'none';
  }
}

async function loadContactAppointments(contactId) {
  const tbody = document.getElementById('contact-appointments-body');
  const countEl = document.getElementById('contact-appointments-count');

  const { data, error } = await db.from('appointments')
    .select('*, typ:lookup_values!appointments_typ_id_fkey(id, wert, farbe)')
    .eq('contact_id', contactId);

  if (error) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Termine';
    return;
  }

  const all = data || [];
  const total = all.length;

  if (total === 0) {
    countEl.textContent = 'Keine Termine';
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Noch keine Termine mit diesem Kontakt. Klicke oben auf „+ Termin hinzufügen".</div></td></tr>';
    return;
  }

  const anzGeplant       = all.filter(a => a.status === 'geplant').length;
  const anzDurchgefuehrt = all.filter(a => a.status === 'durchgefuehrt').length;
  countEl.textContent = `${total} Termin${total === 1 ? '' : 'e'} · ${anzGeplant} geplant · ${anzDurchgefuehrt} durchgeführt`;

  // Sortierung: kommende aufsteigend, dann vergangene absteigend
  const todayISO = toISODate(new Date());
  const upcoming = all.filter(a => a.datum >= todayISO)
    .sort((a, b) => a.datum === b.datum
      ? (a.uhrzeit_von || '').localeCompare(b.uhrzeit_von || '')
      : a.datum.localeCompare(b.datum));
  const past = all.filter(a => a.datum < todayISO)
    .sort((a, b) => a.datum === b.datum
      ? (b.uhrzeit_von || '').localeCompare(a.uhrzeit_von || '')
      : b.datum.localeCompare(a.datum));

  const sorted = upcoming.concat(past);

  tbody.innerHTML = sorted.map(a => {
    const typFarbe = a.typ?.farbe || '#6b7280';
    const typWert  = a.typ?.wert || '—';
    const isPast = a.datum < todayISO;
    const uhrzeit = a.uhrzeit_von
      ? (a.uhrzeit_bis ? `${formatTime(a.uhrzeit_von)}–${formatTime(a.uhrzeit_bis)}` : formatTime(a.uhrzeit_von))
      : '';

    return `
      <tr>
        <td><div class="date-cell${isPast ? ' past' : ''}">${esc(formatDateDE(a.datum))}</div></td>
        <td class="col-tablet" style="color:var(--muted)">${esc(uhrzeit || '—')}</td>
        <td>
          <div class="cell-link" onclick="openAppointmentModal('edit', '${esc(a.id)}')">${esc(a.titel || '—')}</div>
        </td>
        <td class="col-tablet">
          <span class="badge" style="background:${esc(typFarbe)}22;color:${esc(typFarbe)}">${esc(typWert)}</span>
        </td>
        <td>
          <span class="badge" style="background:${appointmentStatusBg(a.status)};color:${appointmentStatusColor(a.status)}">${esc(appointmentStatusLabel(a.status))}</span>
        </td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="openAppointmentModal('edit', '${esc(a.id)}')">Bearbeiten</button>
        </td>
      </tr>`;
  }).join('');
}

async function loadContactProjects(contactId) {
  const tbody = document.getElementById('contact-projects-body');
  const countEl = document.getElementById('contact-projects-count');

  const { data, error } = await db.from('projects')
    .select('*').eq('hauptkontakt_id', contactId)
    .order('startdatum', { ascending: false, nullsFirst: false });

  if (error) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Projekte';
    return;
  }

  const all = data || [];
  const total = all.length;

  if (total === 0) {
    countEl.textContent = 'Keine Projekte als Hauptkontakt';
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Dieser Kontakt ist bisher bei keinem Projekt als Hauptkontakt hinterlegt.</div></td></tr>';
    return;
  }

  const anzAktiv = all.filter(p => ['Lead', 'Angebot', 'In Arbeit'].includes(p.status)).length;
  const anzAbgeschlossen = all.filter(p => p.status === 'Abgeschlossen').length;
  countEl.textContent = `${total} Projekt${total === 1 ? '' : 'e'} · ${anzAktiv} aktiv · ${anzAbgeschlossen} abgeschlossen`;

  // Sortierung wie Firmen-Detail: aktive zuerst
  const sortPrio = { 'In Arbeit': 1, 'Angebot': 2, 'Lead': 3, 'Abgeschlossen': 4, 'Verloren': 5 };
  const sorted = [...all].sort((a, b) => {
    const pa = sortPrio[a.status] || 99;
    const pb = sortPrio[b.status] || 99;
    if (pa !== pb) return pa - pb;
    return (b.startdatum || '').localeCompare(a.startdatum || '');
  });

  tbody.innerHTML = sorted.map(p => {
    const statusColor = projektStatusFarbe(p.status);
    return `
      <tr>
        <td>
          <div class="cell-link" onclick="navigateTo('projekt', '${esc(p.id)}')">${esc(p.name)}</div>
        </td>
        <td><span class="badge" style="background:${esc(statusColor)}22;color:${esc(statusColor)}">${esc(p.status)}</span></td>
        <td class="col-tablet" style="color:var(--muted)">${p.startdatum ? esc(formatDateCompact(p.startdatum)) : '—'}</td>
        <td class="col-tablet" style="color:var(--muted)">${p.enddatum ? esc(formatDateCompact(p.enddatum)) : '—'}</td>
        <td class="col-desktop">${esc(formatPreis(p.geschaetzter_umsatz))}</td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="navigateTo('projekt', '${esc(p.id)}')">Details</button>
        </td>
      </tr>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════════
//  EINSÄTZE (DEPLOYMENTS)
// ═══════════════════════════════════════════════════════════

async function loadEinsatzStatus() {
  if (einsatzStatusCache.length > 0) return einsatzStatusCache;
  const { data, error } = await db.from('lookup_values')
    .select('id, wert, farbe, reihenfolge').eq('kategorie', 'einsatz_status').eq('ist_aktiv', true).order('reihenfolge');
  if (error) { return []; }
  einsatzStatusCache = data || [];
  return einsatzStatusCache;
}

function einsatzStatusFarbe(wert) {
  const s = einsatzStatusCache.find(x => x.wert === wert);
  return s?.farbe || '#6b7280';
}

async function loadServicesCache() {
  if (servicesCache.length > 0) return servicesCache;
  const { data, error } = await db.from('services')
    .select('id, name, einheit, standardpreis, ist_aktiv').eq('ist_aktiv', true).order('name');
  if (error) { return []; }
  servicesCache = data || [];
  return servicesCache;
}

// Kompaktes Datum-Range-Format: "21.04.2026" oder "21.04.–23.04.2026"
function formatDeploymentDateRange(von, bis) {
  if (!von) return '—';
  if (!bis || von === bis) return formatDateDE(von);
  // Beide Daten im selben Jahr?
  const vonD = parseLocalDate(von);
  const bisD = parseLocalDate(bis);
  if (vonD.getFullYear() === bisD.getFullYear()) {
    const vonStr = `${String(vonD.getDate()).padStart(2,'0')}.${String(vonD.getMonth()+1).padStart(2,'0')}.`;
    return `${vonStr}–${formatDateDE(bis).replace(/^[A-Za-z]{2}, /, '')}`;
  }
  return `${formatDateDE(von)} – ${formatDateDE(bis)}`;
}

function calcDeploymentGesamt(menge, einzelpreis) {
  const m = Number(menge) || 0;
  const e = Number(einzelpreis) || 0;
  return m * e;
}

async function loadDeployments() {
  const tbody = document.getElementById('deployments-table-body');
  tbody.innerHTML = '<tr><td colspan="8"><div class="empty">Lade Einsätze ...</div></td></tr>';

  await loadEinsatzStatus();
  await loadServicesCache();

  // Firmen und Projekte für Filter
  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name').order('name');
    companiesCache = cs || [];
  }
  if (projectsCache.length === 0) {
    const { data: ps } = await db.from('projects').select('id, name, company_id').order('name');
    projectsCache = ps || [];
  }

  const companyFilter = document.getElementById('deployments-company-filter');
  const existingCompany = companyFilter.value;
  companyFilter.innerHTML = '<option value="">Alle Firmen</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');
  if (existingCompany) companyFilter.value = existingCompany;

  const projectFilter = document.getElementById('deployments-project-filter');
  const existingProject = projectFilter.value;
  projectFilter.innerHTML = '<option value="">Alle Projekte</option><option value="__none__">Ohne Projekt (Einzelbuchung)</option>'
    + projectsCache.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');
  if (existingProject) projectFilter.value = existingProject;

  const { data, error } = await db.from('deployments')
    .select('*, company:companies(id, name), project:projects(id, name), service:services(id, name, einheit)')
    .order('datum_von', { ascending: false });

  if (error) { tbody.innerHTML = `<tr><td colspan="8"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`; return; }

  deploymentsCache = data || [];
  filterDeployments();
}

function filterDeployments() {
  const searchTerm  = document.getElementById('deployments-search').value.trim().toLowerCase();
  const rangeFilter = document.getElementById('deployments-range-filter').value;
  const statusFilter = document.getElementById('deployments-status-filter').value;
  const companyFilterVal = document.getElementById('deployments-company-filter').value;
  const projectFilterVal = document.getElementById('deployments-project-filter').value;

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const todayISO = toISODate(today);

  let filtered = deploymentsCache;

  // Zeitraum
  if (rangeFilter === 'upcoming') {
    filtered = filtered.filter(d => d.datum_bis >= todayISO);
  } else if (rangeFilter === 'past') {
    filtered = filtered.filter(d => d.datum_bis < todayISO);
  } else if (rangeFilter === 'month') {
    const mStart = toISODate(new Date(today.getFullYear(), today.getMonth(), 1));
    const mEnd   = toISODate(new Date(today.getFullYear(), today.getMonth() + 1, 0));
    filtered = filtered.filter(d => d.datum_von <= mEnd && d.datum_bis >= mStart);
  } else if (rangeFilter === 'quarter') {
    const q = Math.floor(today.getMonth() / 3);
    const qStart = toISODate(new Date(today.getFullYear(), q * 3, 1));
    const qEnd   = toISODate(new Date(today.getFullYear(), q * 3 + 3, 0));
    filtered = filtered.filter(d => d.datum_von <= qEnd && d.datum_bis >= qStart);
  } else if (rangeFilter === 'year') {
    const yStart = toISODate(new Date(today.getFullYear(), 0, 1));
    const yEnd   = toISODate(new Date(today.getFullYear(), 11, 31));
    filtered = filtered.filter(d => d.datum_von <= yEnd && d.datum_bis >= yStart);
  }

  if (statusFilter) filtered = filtered.filter(d => d.status === statusFilter);
  if (companyFilterVal) filtered = filtered.filter(d => d.company_id === companyFilterVal);
  if (projectFilterVal === '__none__') {
    filtered = filtered.filter(d => !d.project_id);
  } else if (projectFilterVal) {
    filtered = filtered.filter(d => d.project_id === projectFilterVal);
  }

  if (searchTerm) {
    filtered = filtered.filter(d => {
      const haystack = [d.titel, d.beschreibung, d.notizen, d.ort, d.externe_techniker,
                        d.company?.name, d.project?.name, d.service?.name]
        .filter(Boolean).join(' ').toLowerCase();
      return haystack.includes(searchTerm);
    });
  }

  renderDeploymentsTable(filtered);
}

function renderDeploymentsTable(deployments) {
  const tbody = document.getElementById('deployments-table-body');
  const countEl = document.getElementById('deployments-count');

  const total = deploymentsCache.length;
  const shown = deployments.length;
  countEl.textContent = (shown === total)
    ? `${total} Einsatz${total === 1 ? '' : '̈e'}`.replace('tz̈e', 'tze')
    : `${shown} von ${total} Einsätzen`;
  // Hinweis zum Umsatz aktiver Einsätze
  const umsatzAktiv = deployments
    .filter(d => ['Durchgeführt', 'Abgerechnet'].includes(d.status) && !d.project_id)
    .reduce((sum, d) => sum + calcDeploymentGesamt(d.menge, d.einzelpreis), 0);
  if (umsatzAktiv > 0) {
    countEl.textContent += ` · ${formatPreis(umsatzAktiv)} direkt abrechenbar`;
  }

  if (shown === 0) {
    const msg = total === 0
      ? 'Noch keine Einsätze angelegt. Klicke oben auf „+ Neuer Einsatz".'
      : 'Keine Einsätze entsprechen den Filterkriterien.';
    tbody.innerHTML = `<tr><td colspan="8"><div class="empty">${msg}</div></td></tr>`;
    return;
  }

  tbody.innerHTML = deployments.map(d => {
    const statusColor = einsatzStatusFarbe(d.status);
    const firmaHtml = d.company
      ? `<div class="cell-link" onclick="navigateTo('firma', '${esc(d.company.id)}')">${esc(d.company.name)}</div>`
      : '<span style="color:var(--muted);font-style:italic">—</span>';
    const projektHtml = d.project
      ? `<div class="cell-link" onclick="navigateTo('projekt', '${esc(d.project.id)}')">${esc(d.project.name)}</div>`
      : '<span style="color:var(--muted);font-style:italic">Einzelbuchung</span>';
    const leistungHtml = d.service
      ? esc(d.service.name)
      : '<span style="color:var(--muted);font-style:italic">—</span>';
    const gesamt = calcDeploymentGesamt(d.menge, d.einzelpreis);

    return `
      <tr>
        <td><div class="date-cell">${esc(formatDeploymentDateRange(d.datum_von, d.datum_bis))}</div></td>
        <td>
          <div class="cell-link" onclick="openDeploymentModal('edit', '${esc(d.id)}')">${esc(d.titel || '—')}</div>
        </td>
        <td class="col-tablet">${firmaHtml}</td>
        <td class="col-desktop">${projektHtml}</td>
        <td class="col-desktop" style="color:var(--muted)">${leistungHtml}</td>
        <td><span class="badge" style="background:${esc(statusColor)}22;color:${esc(statusColor)}">${esc(d.status)}</span></td>
        <td class="col-tablet">${esc(formatPreis(gesamt))}</td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="openDeploymentModal('edit', '${esc(d.id)}')">Bearbeiten</button>
        </td>
      </tr>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════════
//  EINSATZ-MODAL
// ═══════════════════════════════════════════════════════════

async function openDeploymentModal(mode, deploymentId = null) {
  editingDeploymentId = deploymentId;
  selectedTechnikerIds = new Set();

  // Caches sicherstellen
  await Promise.all([loadEinsatzStatus(), loadServicesCache(), loadUserProfilesCache()]);

  if (companiesCache.length === 0) {
    const { data: cs } = await db.from('companies').select('id, name, strasse, plz, stadt').order('name');
    companiesCache = cs || [];
  } else {
    const { data: cs } = await db.from('companies').select('id, name, strasse, plz, stadt').order('name');
    companiesCache = cs || companiesCache;
  }

  const companySelect = document.getElementById('d-company');
  companySelect.innerHTML = '<option value="">— Firma wählen —</option>'
    + companiesCache.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');

  // Service-Dropdown
  const serviceSelect = document.getElementById('d-service');
  serviceSelect.innerHTML = '<option value="">— Keine Leistung —</option>'
    + servicesCache.map(s => `<option value="${esc(s.id)}" data-preis="${s.standardpreis || 0}" data-einheit="${esc(s.einheit || '')}">${esc(s.name)} (${esc(s.einheit || '—')})</option>`).join('');

  // Status-Select
  document.getElementById('d-status').value = 'Geplant';

  // Felder zurücksetzen
  document.getElementById('d-titel').value = '';
  const todayISO = toISODate(new Date());
  document.getElementById('d-datum-von').value = todayISO;
  document.getElementById('d-datum-bis').value = todayISO;
  document.getElementById('d-uhrzeit-von').value = '';
  document.getElementById('d-uhrzeit-bis').value = '';
  document.getElementById('d-ort').value = '';
  document.getElementById('d-ort-hint').style.display = 'none';
  document.getElementById('d-menge').value = '1';
  document.getElementById('d-einzelpreis').value = '';
  document.getElementById('d-beschreibung').value = '';
  document.getElementById('d-notizen').value = '';
  document.getElementById('d-externe-techniker').value = '';
  document.getElementById('d-create-appointment').checked = false;

  renderTechnikerChipsForDeployment();
  await rebuildProjectDropdownForDeployment('');
  updateDeploymentPriceHint();

  setupDeploymentModalListeners();

  if (mode === 'new') {
    document.getElementById('modal-deployment-title').textContent = 'Neuer Einsatz';
    document.getElementById('d-save-btn').textContent = 'Anlegen';
    document.getElementById('d-delete-btn').style.display = 'none';

    // Prefill aus Firmen-Detail / Projekt-Detail
    if (deploymentModalPrefillCompanyId) {
      companySelect.value = deploymentModalPrefillCompanyId;
      await rebuildProjectDropdownForDeployment(deploymentModalPrefillCompanyId);
      updateDeploymentOrtHint();
      deploymentModalPrefillCompanyId = null;
    }
    if (deploymentModalPrefillProjectId) {
      // Projekt laden + dessen Firma setzen, falls noch nicht
      const { data: proj } = await db.from('projects')
        .select('id, name, company_id').eq('id', deploymentModalPrefillProjectId).single();
      if (proj) {
        if (proj.company_id) {
          companySelect.value = proj.company_id;
          await rebuildProjectDropdownForDeployment(proj.company_id);
          updateDeploymentOrtHint();
        }
        document.getElementById('d-project').value = proj.id;
      }
      deploymentModalPrefillProjectId = null;
    }
    updateDeploymentPriceHint();
  } else {
    document.getElementById('modal-deployment-title').textContent = 'Einsatz bearbeiten';
    document.getElementById('d-save-btn').textContent = 'Speichern';
    document.getElementById('d-delete-btn').style.display = 'block';

    const { data, error } = await db.from('deployments').select('*').eq('id', deploymentId).single();
    if (error || !data) { showToast('Einsatz konnte nicht geladen werden: ' + (error?.message || 'Unbekannter Fehler'), true); editingDeploymentId = null; return; }

    document.getElementById('d-titel').value = data.titel || '';
    document.getElementById('d-datum-von').value = data.datum_von || '';
    document.getElementById('d-datum-bis').value = data.datum_bis || '';
    document.getElementById('d-uhrzeit-von').value = data.uhrzeit_von ? data.uhrzeit_von.substring(0, 5) : '';
    document.getElementById('d-uhrzeit-bis').value = data.uhrzeit_bis ? data.uhrzeit_bis.substring(0, 5) : '';
    document.getElementById('d-status').value = data.status || 'Geplant';
    document.getElementById('d-ort').value = data.ort || '';
    document.getElementById('d-menge').value = data.menge ?? 1;
    document.getElementById('d-einzelpreis').value = data.einzelpreis ?? '';
    document.getElementById('d-beschreibung').value = data.beschreibung || '';
    document.getElementById('d-notizen').value = data.notizen || '';
    document.getElementById('d-externe-techniker').value = data.externe_techniker || '';

    if (data.company_id) {
      companySelect.value = data.company_id;
      await rebuildProjectDropdownForDeployment(data.company_id);
      if (data.project_id) document.getElementById('d-project').value = data.project_id;
      updateDeploymentOrtHint();
    }

    if (data.service_id) serviceSelect.value = data.service_id;

    // Techniker laden
    const { data: techRows } = await db.from('deployment_technicians')
      .select('user_id').eq('deployment_id', deploymentId);
    selectedTechnikerIds = new Set((techRows || []).map(t => t.user_id));
    renderTechnikerChipsForDeployment();

    // Verknüpften Termin prüfen
    const { data: linkedAppt } = await db.from('appointments')
      .select('id').eq('deployment_id', deploymentId).limit(1);
    document.getElementById('d-create-appointment').checked = (linkedAppt || []).length > 0;

    updateDeploymentPriceHint();
  }

  document.getElementById('modal-deployment').classList.add('open');
  setTimeout(() => document.getElementById('d-titel').focus(), 100);
}

function setupDeploymentModalListeners() {
  const companySelect = document.getElementById('d-company');
  const serviceSelect = document.getElementById('d-service');
  const datumVon = document.getElementById('d-datum-von');
  const datumBis = document.getElementById('d-datum-bis');
  const menge = document.getElementById('d-menge');
  const einzelpreis = document.getElementById('d-einzelpreis');

  companySelect.onchange = async () => {
    await rebuildProjectDropdownForDeployment(companySelect.value);
    updateDeploymentOrtHint();
    updateDeploymentPriceHint();
  };

  document.getElementById('d-project').onchange = () => {
    updateDeploymentPriceHint();
  };

  serviceSelect.onchange = () => {
    // Auto-fill Einzelpreis aus Service-Standardpreis, wenn noch leer
    const opt = serviceSelect.options[serviceSelect.selectedIndex];
    const preis = opt?.getAttribute('data-preis');
    const currentPreis = document.getElementById('d-einzelpreis').value;
    if (preis && (currentPreis === '' || Number(currentPreis) === 0)) {
      document.getElementById('d-einzelpreis').value = preis;
    }
    updateDeploymentPriceHint();
  };

  datumVon.onchange = () => {
    // datum_bis mit-anpassen wenn vorher = datum_von oder leer
    if (!datumBis.value || datumBis.value < datumVon.value) {
      datumBis.value = datumVon.value;
    }
  };

  [menge, einzelpreis].forEach(el => {
    el.oninput = updateDeploymentPriceHint;
  });
}

function updateDeploymentOrtHint() {
  const companyId = document.getElementById('d-company').value;
  const hint = document.getElementById('d-ort-hint');
  if (!companyId) { hint.style.display = 'none'; return; }
  const company = companiesCache.find(c => c.id === companyId);
  if (!company) { hint.style.display = 'none'; return; }
  const parts = [company.strasse, [company.plz, company.stadt].filter(Boolean).join(' ')].filter(Boolean);
  if (parts.length === 0) { hint.style.display = 'none'; return; }
  hint.innerHTML = `Firmenadresse: ${esc(parts.join(', '))} <span style="text-decoration:underline">· übernehmen</span>`;
  hint.style.display = '';
}

function useCompanyAddressForDeploymentOrt() {
  const companyId = document.getElementById('d-company').value;
  if (!companyId) return;
  const company = companiesCache.find(c => c.id === companyId);
  if (!company) return;
  const parts = [company.strasse, [company.plz, company.stadt].filter(Boolean).join(' ')].filter(Boolean);
  if (parts.length === 0) return;
  document.getElementById('d-ort').value = parts.join(', ');
}

function updateDeploymentPriceHint() {
  const hintEl = document.getElementById('d-preis-hint');
  const menge = Number(document.getElementById('d-menge').value) || 0;
  const einzel = Number(document.getElementById('d-einzelpreis').value) || 0;
  const gesamt = menge * einzel;
  const projectId = document.getElementById('d-project').value;

  if (projectId) {
    hintEl.innerHTML = `Gesamt: <strong>${esc(formatPreis(gesamt))}</strong> · Interner Aufwand. Kundenumsatz läuft über den Projekt-Paketpreis.`;
  } else {
    hintEl.innerHTML = `Gesamt: <strong>${esc(formatPreis(gesamt))}</strong> · Wird direkt dem Kunden berechnet.`;
  }
}

async function rebuildProjectDropdownForDeployment(companyId) {
  const select = document.getElementById('d-project');
  if (!select) return;
  if (!companyId) {
    select.innerHTML = '<option value="">— Kein Projekt (Einzelbuchung) —</option>';
    return;
  }
  const { data, error } = await db.from('projects')
    .select('id, name, status').eq('company_id', companyId)
    .in('status', ['Lead', 'Angebot', 'In Arbeit', 'Abgeschlossen'])
    .order('name');
  if (error) { select.innerHTML = '<option value="">Fehler beim Laden</option>'; return; }
  const projects = data || [];
  select.innerHTML = '<option value="">— Kein Projekt (Einzelbuchung) —</option>'
    + projects.map(p => `<option value="${esc(p.id)}">${esc(p.name)} · ${esc(p.status)}</option>`).join('');
}

function renderTechnikerChipsForDeployment() {
  const wrap = document.getElementById('d-techniker-list');
  if (userProfilesCache.length === 0) {
    wrap.innerHTML = '<span style="font-size:12px;color:var(--muted)">Keine internen Techniker verfügbar.</span>';
    return;
  }
  wrap.innerHTML = userProfilesCache.map(u => {
    const selected = selectedTechnikerIds.has(u.id);
    return `
      <div class="techniker-chip${selected ? ' selected' : ''}" data-user-id="${esc(u.id)}"
           onclick="toggleTechnikerChip('${esc(u.id)}')">
        <span class="techniker-chip-avatar">${esc(ini(u.name))}</span>
        <span>${esc(u.name)}</span>
      </div>`;
  }).join('');
}

function toggleTechnikerChip(userId) {
  if (selectedTechnikerIds.has(userId)) selectedTechnikerIds.delete(userId);
  else selectedTechnikerIds.add(userId);
  renderTechnikerChipsForDeployment();
}

function closeDeploymentModal() {
  document.getElementById('modal-deployment').classList.remove('open');
  editingDeploymentId = null;
  deploymentModalPrefillCompanyId = null;
  deploymentModalPrefillProjectId = null;
  selectedTechnikerIds = new Set();
}

async function saveDeployment() {
  const titel         = document.getElementById('d-titel').value.trim();
  const datum_von     = document.getElementById('d-datum-von').value;
  const datum_bis     = document.getElementById('d-datum-bis').value;
  const uhrzeit_von   = document.getElementById('d-uhrzeit-von').value;
  const uhrzeit_bis   = document.getElementById('d-uhrzeit-bis').value;
  const status        = document.getElementById('d-status').value;
  const company_id    = document.getElementById('d-company').value || null;
  const project_id    = document.getElementById('d-project').value || null;
  const service_id    = document.getElementById('d-service').value || null;
  const mengeRaw      = document.getElementById('d-menge').value;
  const einzelRaw     = document.getElementById('d-einzelpreis').value;
  const ort           = document.getElementById('d-ort').value.trim();
  const beschreibung  = document.getElementById('d-beschreibung').value.trim();
  const notizen       = document.getElementById('d-notizen').value.trim();
  const externe_techniker = document.getElementById('d-externe-techniker').value.trim();
  const createAppointment = document.getElementById('d-create-appointment').checked;
  const btn           = document.getElementById('d-save-btn');

  if (!titel)     { showToast('Bitte Titel eingeben.', true); return; }
  if (!datum_von) { showToast('Bitte Datum von wählen.', true); return; }
  if (!datum_bis) { showToast('Bitte Datum bis wählen.', true); return; }
  if (datum_bis < datum_von) { showToast('Datum bis muss nach Datum von liegen.', true); return; }
  if (!company_id) { showToast('Bitte Firma auswählen.', true); return; }
  if (!['Geplant', 'Durchgeführt', 'Abgerechnet', 'Storniert'].includes(status)) {
    showToast('Status ungültig.', true); return;
  }
  if (uhrzeit_von && uhrzeit_bis && uhrzeit_von >= uhrzeit_bis) {
    showToast('„Uhrzeit bis" muss nach „Uhrzeit von" liegen.', true); return;
  }

  const menge = mengeRaw === '' ? 1 : Number(mengeRaw);
  if (Number.isNaN(menge) || menge < 0) { showToast('Menge muss eine Zahl ≥ 0 sein.', true); return; }
  const einzelpreis = einzelRaw === '' ? 0 : Number(einzelRaw);
  if (Number.isNaN(einzelpreis) || einzelpreis < 0) { showToast('Einzelpreis muss eine Zahl ≥ 0 sein.', true); return; }

  btn.disabled = true;
  btn.textContent = editingDeploymentId ? 'Wird gespeichert ...' : 'Wird angelegt ...';

  try {
    const payload = {
      titel, datum_von, datum_bis,
      uhrzeit_von: uhrzeit_von || null,
      uhrzeit_bis: uhrzeit_bis || null,
      status,
      company_id, project_id, service_id,
      menge, einzelpreis,
      ort: ort || null,
      beschreibung: beschreibung || null,
      notizen: notizen || null,
      externe_techniker: externe_techniker || null
    };
    if (!editingDeploymentId) payload.erstellt_von = currentUser?.id || null;

    let saved;
    if (editingDeploymentId) {
      const { data, error } = await db.from('deployments').update(payload).eq('id', editingDeploymentId).select().single();
      if (error) throw new Error(error.message);
      saved = data;
    } else {
      const { data, error } = await db.from('deployments').insert(payload).select().single();
      if (error) throw new Error(error.message);
      saved = data;
    }

    // ──────── Techniker-Relations synchronisieren ────────
    // Zuerst alle existierenden löschen, dann neu anlegen (simpler als Diff)
    await db.from('deployment_technicians').delete().eq('deployment_id', saved.id);
    if (selectedTechnikerIds.size > 0) {
      const techRows = [...selectedTechnikerIds].map(uid => ({ deployment_id: saved.id, user_id: uid }));
      const { error: techErr } = await db.from('deployment_technicians').insert(techRows);
      if (techErr) {
        console.warn('Techniker konnten nicht gespeichert werden:', techErr.message);
        showToast('Einsatz gespeichert, Techniker-Zuordnung fehlgeschlagen.', true);
      }
    }

    // ──────── Termin-Kopplung ────────
    await syncDeploymentAppointment(saved, createAppointment);

    closeDeploymentModal();
    showToast(editingDeploymentId ? 'Einsatz aktualisiert.' : 'Einsatz angelegt.');

    // Kontext-sensibles Refresh
    if (currentProjectDetailId && document.getElementById('page-project-detail').classList.contains('active')) {
      await loadProjectDeployments(currentProjectDetailId);
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await loadCompanyDeployments(currentCompanyDetailId);
    } else {
      await loadDeployments();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = editingDeploymentId ? 'Speichern' : 'Anlegen';
  }
}

/**
 * Synchronisiert einen Termin zum Einsatz basierend auf Checkbox-Status.
 * - Checkbox an + kein verknüpfter Termin → neuen Termin anlegen
 * - Checkbox an + existiert → updaten
 * - Checkbox aus + existiert → entkoppeln (deployment_id=null), Termin bleibt
 * - Checkbox aus + nicht existiert → nichts
 */
async function syncDeploymentAppointment(deployment, shouldHaveAppointment) {
  const { data: existing } = await db.from('appointments')
    .select('id').eq('deployment_id', deployment.id).limit(1);
  const existingId = existing?.[0]?.id;

  if (!shouldHaveAppointment) {
    if (existingId) {
      // Entkoppeln, nicht löschen
      await db.from('appointments').update({ deployment_id: null }).eq('id', existingId);
    }
    return;
  }

  // Default-Termintyp: "Vor Ort" suchen, sonst erster aktiver
  await loadTerminTypen();
  const typVorOrt = terminTypenCache.find(t => /vor[- ]?ort/i.test(t.wert)) || terminTypenCache[0];
  const typ_id = typVorOrt?.id || null;

  // Terminstatus: Geplant → 'geplant', sonst 'durchgefuehrt'
  const terminStatus = deployment.status === 'Geplant' ? 'geplant' : 'durchgefuehrt';

  const payload = {
    titel: deployment.titel,
    datum: deployment.datum_von,
    uhrzeit_von: deployment.uhrzeit_von,
    uhrzeit_bis: deployment.uhrzeit_bis,
    status: terminStatus,
    company_id: deployment.company_id,
    project_id: deployment.project_id,
    ort: deployment.ort,
    notizen: deployment.notizen ? `[Einsatz-Termin]\n${deployment.notizen}` : '[Einsatz-Termin]',
    typ_id,
    deployment_id: deployment.id
  };

  if (existingId) {
    await db.from('appointments').update(payload).eq('id', existingId);
  } else {
    payload.erstellt_von = currentUser?.id || null;
    await db.from('appointments').insert(payload);
  }
}

async function deleteDeployment() {
  if (!editingDeploymentId) return;
  if (!confirm('Einsatz wirklich löschen?\n\nHinweis: Zugeordnete Techniker-Zuordnungen werden automatisch entfernt. Ein verknüpfter Termin bleibt erhalten (wird nur entkoppelt).')) return;

  const btn = document.getElementById('d-delete-btn');
  btn.disabled = true;
  btn.textContent = 'Wird gelöscht ...';

  try {
    const { error } = await db.from('deployments').delete().eq('id', editingDeploymentId);
    if (error) throw new Error(error.message);

    closeDeploymentModal();
    showToast('Einsatz gelöscht.');

    if (currentProjectDetailId && document.getElementById('page-project-detail').classList.contains('active')) {
      await loadProjectDeployments(currentProjectDetailId);
    } else if (currentCompanyDetailId && document.getElementById('page-company-detail').classList.contains('active')) {
      await loadCompanyDeployments(currentCompanyDetailId);
    } else {
      await loadDeployments();
    }
  } catch (e) {
    showToast(e.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Löschen';
  }
}

// ═══════════════════════════════════════════════════════════
//  EINSÄTZE AUF FIRMA-DETAIL
// ═══════════════════════════════════════════════════════════

async function loadCompanyDeployments(companyId) {
  const tbody = document.getElementById('company-deployments-body');
  const countEl = document.getElementById('company-deployments-count');

  await loadEinsatzStatus();

  const { data, error } = await db.from('deployments')
    .select('*, project:projects(id, name), service:services(id, name)')
    .eq('company_id', companyId)
    .order('datum_von', { ascending: false });

  if (error) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Einsätze';
    return;
  }

  const all = data || [];
  const total = all.length;

  if (total === 0) {
    countEl.textContent = 'Keine Einsätze';
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Noch keine Einsätze für diese Firma. Klicke oben auf „+ Einsatz hinzufügen".</div></td></tr>';
    return;
  }

  const umsatz = all
    .filter(d => !d.project_id && ['Durchgeführt', 'Abgerechnet'].includes(d.status))
    .reduce((sum, d) => sum + calcDeploymentGesamt(d.menge, d.einzelpreis), 0);

  countEl.textContent = `${total} Einsatz${total === 1 ? '' : 'e'}`
    + (umsatz > 0 ? ` · ${formatPreis(umsatz)} direkt abrechenbar` : '');

  tbody.innerHTML = all.map(d => {
    const statusColor = einsatzStatusFarbe(d.status);
    const projektHtml = d.project
      ? `<div class="cell-link" onclick="navigateTo('projekt', '${esc(d.project.id)}')">${esc(d.project.name)}</div>`
      : '<span style="color:var(--muted);font-style:italic">Einzelbuchung</span>';
    const gesamt = calcDeploymentGesamt(d.menge, d.einzelpreis);

    return `
      <tr>
        <td><div class="date-cell">${esc(formatDeploymentDateRange(d.datum_von, d.datum_bis))}</div></td>
        <td>
          <div class="cell-link" onclick="openDeploymentModal('edit', '${esc(d.id)}')">${esc(d.titel || '—')}</div>
        </td>
        <td class="col-tablet">${projektHtml}</td>
        <td><span class="badge" style="background:${esc(statusColor)}22;color:${esc(statusColor)}">${esc(d.status)}</span></td>
        <td class="col-desktop">${esc(formatPreis(gesamt))}</td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="openDeploymentModal('edit', '${esc(d.id)}')">Bearbeiten</button>
        </td>
      </tr>`;
  }).join('');
}

// ═══════════════════════════════════════════════════════════
//  EINSÄTZE AUF PROJEKT-DETAIL
// ═══════════════════════════════════════════════════════════

async function loadProjectDeployments(projectId) {
  const tbody = document.getElementById('project-deployments-body');
  const countEl = document.getElementById('project-deployments-count');
  const summaryEl = document.getElementById('project-deployments-summary');

  await loadEinsatzStatus();

  const { data, error } = await db.from('deployments')
    .select('*, service:services(id, name)')
    .eq('project_id', projectId)
    .order('datum_von');

  if (error) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="empty">Fehler: ${esc(error.message)}</div></td></tr>`;
    countEl.textContent = 'Einsätze';
    summaryEl.style.display = 'none';
    return;
  }

  const all = data || [];
  const total = all.length;

  if (total === 0) {
    countEl.textContent = 'Keine Einsätze';
    tbody.innerHTML = '<tr><td colspan="6"><div class="empty">Noch keine Einsätze für dieses Projekt. Klicke oben auf „+ Einsatz hinzufügen".</div></td></tr>';
    summaryEl.style.display = 'none';
    return;
  }

  const anzGeplant      = all.filter(d => d.status === 'Geplant').length;
  const anzDurchgefuehrt = all.filter(d => d.status === 'Durchgeführt').length;
  const anzAbgerechnet  = all.filter(d => d.status === 'Abgerechnet').length;
  const summeAufwand    = all.reduce((s, d) => s + calcDeploymentGesamt(d.menge, d.einzelpreis), 0);

  countEl.textContent = `${total} Einsatz${total === 1 ? '' : 'e'} · ${anzGeplant} geplant · ${anzDurchgefuehrt} durchgef. · ${anzAbgerechnet} abgerechnet`;

  tbody.innerHTML = all.map(d => {
    const statusColor = einsatzStatusFarbe(d.status);
    const leistungHtml = d.service
      ? esc(d.service.name)
      : '<span style="color:var(--muted);font-style:italic">—</span>';
    const gesamt = calcDeploymentGesamt(d.menge, d.einzelpreis);

    return `
      <tr>
        <td><div class="date-cell">${esc(formatDeploymentDateRange(d.datum_von, d.datum_bis))}</div></td>
        <td>
          <div class="cell-link" onclick="openDeploymentModal('edit', '${esc(d.id)}')">${esc(d.titel || '—')}</div>
        </td>
        <td class="col-tablet" style="color:var(--muted)">${leistungHtml}</td>
        <td><span class="badge" style="background:${esc(statusColor)}22;color:${esc(statusColor)}">${esc(d.status)}</span></td>
        <td class="col-desktop">${esc(formatPreis(gesamt))}</td>
        <td class="col-action" style="text-align:right">
          <button class="btn btn-sm" onclick="openDeploymentModal('edit', '${esc(d.id)}')">Bearbeiten</button>
        </td>
      </tr>`;
  }).join('');

  // Summary mit Aufwands-Info
  summaryEl.style.display = '';
  summaryEl.innerHTML = `Interner Aufwand laut Einsatz-Preisen: <strong>${esc(formatPreis(summeAufwand))}</strong>. Kundenumsatz läuft über den Projekt-Paketpreis.`;
}

// ═══════════════════════════════════════════════════════════
//  INITIALIZATION
// ═══════════════════════════════════════════════════════════

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAuth);
} else {
  initAuth();
}
